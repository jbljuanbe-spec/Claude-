# 📘 Mi Japonés con Claude — Libro de Lecciones

**Punto de partida (sesión 1):** lee hiragana/katakana con dudas y sin conectar sonido-significado todavía; ~4 kanji; gramática casi nula más allá de presentarse.
**Meta:** ~150 sesiones → conversación básica · ~300 → conversación fluida y detallada · ~600 → dominio completo.
**Método:** input comprensible + gramática explícita + práctica activa + repaso espaciado. Cada sesión amplía este libro y el Workbook adjunto.
**Recurso complementario:** NHK World "Easy Japanese" (48 lecciones cortas en español, con audio — serie tipo sitcom de un estudiante en Tokio). Útil para oído y frases naturales; señalaré el número de episodio cuando encaje con la gramática que estemos viendo.
**Control de calidad:** cada 5 lecciones, el Workbook incluye un Test de repaso acumulativo (lectura, partículas, conjugación, traducción, corrección de errores, producción libre) antes de seguir. Referencia cruzada de contenidos con Genki y Minna no Nihongo para no dejar huecos estructurales. **Cobertura de tarjetas:** cada lección debe aportar tarjeta para el 100% de su vocabulario nuevo (no una selección), más conjugación de cada patrón nuevo que introduzca — auditado y corregido tras detectar huecos en L1/L4/L6/L8.

---

## 🔢 Números 1-100 y la hora (repaso, sin lección dedicada)

**Números base:** 0(ゼロ/れい)・1(いち)・2(に)・3(さん)・4(し/よん)・5(ご)・6(ろく)・7(しち/なな)・8(はち)・9(きゅう/く)・10(じゅう)
**11-19:** じゅう+número (じゅういち=11, じゅうご=15...). **Decenas:** número+じゅう (にじゅう=20, さんじゅう=30...きゅうじゅう=90). **100:** ひゃく. Se combinan: にじゅうさん=23.

**La hora:** 〜時(じ) hora, 〜分(ふん/ぷん) minutos. 何時ですか (¿qué hora es?).
⚠️ Excepciones de lectura: 4時=よじ (no よんじ), 9時=くじ (no きゅうじ). En 分, el sonido cambia con 1,3,6,8,10: 1分いっぷん・3分さんぷん・6分ろっぷん・8分はっぷん・10分じゅっぷん.



## 🗺️ Hoja de ruta (índice Genki I, confirmado por el usuario)

| Lección | Tema | Gramática clave |
|---|---|---|
| 1 | あたらしいともだち (New Friends) | Xは Yです · preguntas · noun1のnoun2 |
| 2 | かいもの (Shopping) | これ/それ/あれ/どれ · この/その/あの/どの · ここ/そこ/あそこ/どこ · だれの · noun も · noun じゃないです · ~ね/~よ |
| 3 | デートの約束 (Making a Date) | Conjugación verbal · tipos de verbo y "presente" · partículas · referencia temporal · orden de palabras · adverbios de frecuencia · は como tema |
| 4 | 初めてのデート (The First Date) | descripción de cosas/lugares · pasado de です · が · ~枚 · たくさん · と |
| 5 | 沖縄旅行 (A Trip to Okinawa) | adjetivos (い/な) · 好き/嫌い · ~ましょう/~ましょうか · contar objetos |
| 6 | ロバートさんの一日 (A Day in Robert's Life) | forma て · ~てください · ~てもいいです · ~てはいけません · ~から · ~ましょうか |
| 7 | 家族の写真 (Family Picture) | ~ている · て-form para unir frases · verbo+に行く · contar personas |
| 8 | バーベキュー (Barbecue) | formas simples (informal) · ~と思います/~と言っていました · ~ないでください · 何か/何も |
| 9 | かぶき (Kabuki) | pasado informal · calificar sustantivos con verbos/adjetivos · まだ~ていません · ~から (razón) |
| 10 | 冬休みの予定 (Winter Vacation Plans) | comparaciones (2 y 3+ elementos) · adj/noun +の · adj+なる · どちらか/どこにも · で |
| 11 | 休みのあと (After the Vacation) | ~たい · ~たり~たりする · ~ことがある · noun A や noun B |
| 12+ | *(pendiente, no visible en el índice subido)* | — |

*(Nota: el usuario tiene el libro físico y puede subir páginas puntuales si hace falta consultar un ejercicio o matiz concreto.)*

---

## Lección 1 — あいさつ・自己紹介 (Saludos y autopresentación)

### Objetivos de la lección
- Conectar la lectura del hiragana con el significado real (no solo "sonar" las sílabas).
- Presentarte y preguntar por otros: estructura **A は B です**.
- Partículas: **は・です・か・も・の**.

### 1. La estructura base: A は B です
「は」 marca el **tema** de la frase (equivale aprox. a "en cuanto a A..."). Ojo: como partícula se **lee "wa"**, aunque se escriba con el carácter は (ha).
「です」 es el verbo "ser/estar" en su forma neutra-formal. No cambia por singular/plural ni por género.

私は学生です。(わたしは がくせいです) — Yo soy estudiante.
田中さんは先生です。(たなかさんは せんせいです) — El/la Sr./Sra. Tanaka es profesor/a.

👉 **さん** es un honorífico (Sr./Sra./Srta.) que se pone detrás del nombre de **otra persona**. Nunca lo uses con tu propio nombre.

### 2. Preguntas: 〜か
Se añade **か** al final de la frase con です para hacerla pregunta. No se cambia el orden de palabras ni hace falta "¿?" (aunque en textos modernos a veces se usa igualmente).

あなたは学生ですか。 — ¿Eres estudiante?
- Respuesta afirmativa: はい、そうです。(Sí, así es.)
- Respuesta negativa: いいえ、学生じゃありません。(No, no soy estudiante.) — *じゃありません* es la forma negativa hablada de です; la forma escrita/formal es *ではありません*.

### 3. も — "también"
Sustituye a は cuando el tema comparte la misma categoría que la frase anterior.

私は学生です。田中さんも学生です。 — Yo soy estudiante. Tanaka también es estudiante.

### 4. の — posesión / conexión
Conecta dos sustantivos, el segundo "pertenece" o se relaciona con el primero (como "de" en español, pero en orden inverso).

私の名前 (わたしの なまえ) — mi nombre
スペインの学生 — estudiante de España (lit. "de España + estudiante")

### 5. Pronombres y honoríficos básicos
| Palabra | Lectura | Significado |
|---|---|---|
| 私 | わたし | yo |
| あなた | あなた | tú *(úsalo poco; en japonés se prefiere el nombre + さん)* |
| 〜さん | - | Sr./Sra./Srta. (para otros, nunca para ti mismo) |

### Vocabulario de la lección
| Kanji/Kana | Lectura | Significado |
|---|---|---|
| 名前 | なまえ | nombre |
| 学生 | がくせい | estudiante |
| 先生 | せんせい | profesor/a |
| 会社員 | かいしゃいん | empleado/a de empresa |
| 医者 | いしゃ | médico/a |
| 〜人 | 〜じん | sufijo de nacionalidad (ej. スペイン人 = español/a) |
| 日本 | にほん | Japón |
| スペイン | すぺいん | España |
| はじめまして | - | "Mucho gusto" (solo al conocer a alguien por primera vez) |
| よろしくおねがいします | - | fórmula fija de cortesía al presentarse (sin traducción literal exacta) |
| こちらこそ | - | "el gusto es mío" / "lo mismo digo" |
| そうです | - | "así es" / "correcto" |

### Diálogo modelo
> A: はじめまして。私はアナです。スペイン人です。学生です。よろしくお願いします。
> B: はじめまして。田中です。会社員です。こちらこそよろしくお願いします。
> A: 田中さんも学生ですか。
> B: いいえ、学生じゃありません。会社員です。

### Nota de lectura (para tu punto débil: sonido → significado)
Cuando leas hiragana, no leas sílaba por sílaba: **agrupa por palabra**. わたし se lee como un bloque "watashi" = "yo", no w-a-t-a-s-h-i sin sentido. Practica esto en los deberes de hoy.

### 🏮 Nota cultural: にほんじんの なまえ (los nombres japoneses)
- Orden **apellido + nombre** (al revés que en español): 田中さくら = apellido 田中, nombre さくら. En contextos formales/laborales, casi siempre te dirigirán por el apellido +さん, nunca por el nombre solo.
- 〜さん es neutro en género y se usa con casi todo el mundo que no sea de tu círculo cercano. Usar el nombre de pila a secas (sin さん) con alguien que no es de tu familia o amigo íntimo se considera demasiado directo.
- Como extranjero, tu nombre se escribe en **katakana** (ホアン, フアン) — es lo normal y esperado, no hace falta "japonizarlo" de otra forma.

---

## Lección 2 — かいもの (Shopping)

### Objetivos de la lección
- Señalar y preguntar por objetos: これ/それ/あれ/どれ y この/その/あの/どの.
- Ubicar cosas y lugares: ここ/そこ/あそこ/どこ.
- Negar con です: 〜じゃないです / 〜じゃありません.
- Matizar con partículas finales ね y よ.

### 1. これ/それ/あれ/どれ vs この/その/あの/どの
Japonés usa un sistema de **3 distancias** (こ-cerca de mí, そ-cerca de ti, あ-lejos de los dos) + 1 interrogativo (ど-cuál/dónde). Es el mismo patrón en todas las series:

| Serie | Pronombre (solo, "esto/eso...") | + noun ("este/ese... X") | Lugar |
|---|---|---|---|
| こ (cerca de mí) | これ | この＋noun | ここ (aquí) |
| そ (cerca de ti) | それ | その＋noun | そこ (ahí) |
| あ (lejos de ambos) | あれ | あの＋noun | あそこ (allí) |
| ど (pregunta) | どれ (¿cuál?) | どの＋noun | どこ (¿dónde?) |

⚠️ Diferencia clave: これ/それ/あれ/どれ van **solos** (reemplazan al sustantivo). この/その/あの/どの **siempre** necesitan un sustantivo detrás — nunca se usan solos.

これは本です。(Esto es un libro.) ✅
この本です。(✗ incompleto — falta el sustantivo real, esto solo funciona como この本は〜 o similar)

📌 No confundas どれ (¿cuál? — elegir entre varias cosas) con どこ (¿dónde? — ubicación). Suenan parecido, son categorías distintas.

### 2. だれの + noun — "¿de quién es...?"
それはだれのかばんですか。 — ¿De quién es esa bolsa?
それは私のです。 — Es mía. *(の puede reemplazar al sustantivo repetido: 私の(かばん) = "la mía")*

### 3. Negación: 〜じゃないです / 〜じゃありません
Dos formas, mismo significado (negativo de です). じゃないです es ligeramente más hablado/casual; じゃありません es la que ya usaste y es un poco más "de manual". Ambas son perfectamente naturales en conversación.

これは私のかさじゃないです。＝ これは私のかさじゃありません。 — Este no es mi paraguas.

📌 En realidad hay **4 combinaciones**, todas correctas y educadas: じゃ/ではありません, じゃ/ではないです (じゃ es la contracción hablada de では). Y ojo: la partícula は suena "wa" pero siempre se escribe は, nunca わ — でわ no existe.

### 4. Partículas finales ね y よ
| Partícula | Uso | Ejemplo |
|---|---|---|
| ね | buscas acuerdo/confirmación ("¿verdad?", "¿no?") | いい天気ですね。(Hace buen tiempo, ¿verdad?) |
| よ | das información nueva que el otro no sabe (énfasis) | このかばんは高いですよ。(Este bolso es caro, ¿eh? — te aviso) |

📌 Si estás **reaccionando** a algo que te acaban de decir, va ね, no よ (よ es para cuando informas TÚ, no para reaccionar).

### Vocabulario de la lección
| Kanji/Kana | Lectura | Significado |
|---|---|---|
| 傘 | かさ | paraguas |
| 時計 | とけい | reloj |
| 本 | ほん | libro |
| 辞書 | じしょ | diccionario |
| かばん | かばん | bolso/maletín |
| だれ | だれ | quién |
| なん/なに | なん/なに | qué |
| いくらですか | - | ¿cuánto cuesta? |
| すみません | - | disculpa/perdón (para llamar la atención) |
| 高い | たかい | caro/alto *(adjetivo, se ve formalmente en la Lección 5, aquí solo vocabulario)* |
| 天気 | てんき | tiempo (clima) |

### Diálogo modelo
> A: すみません、これはいくらですか。
> B: それは３０００円です。
> A: そうですか。じゃあ、あれは？
> B: あれは私のかさですよ。売り物じゃないです。
> A: あ、すみません！

*(売り物 = うりもの = artículo en venta — vocabulario extra solo para el contexto del diálogo, no hace falta memorizarlo aún)*

### 🏮 Nota cultural: にほんの おかね (el dinero en Japón)
- Moneda: 円 (えん, yen). No hay decimales — no existe el equivalente a los céntimos.
- Billetes comunes: 1000円, 5000円, 10000円. Monedas: 1, 5, 10, 50, 100, 500円.
- Japón sigue siendo muy dependiente del **efectivo**, aunque el pago con tarjeta/móvil ha crecido mucho. Lleva siempre algo de cash.
- **No se da propina** — en tiendas, restaurantes o taxis, dejar propina puede incluso resultar confuso o incómodo para el que la recibe.

---

## Lección 3 — デートの約束 (Quedar con alguien)

### Objetivos de la lección
- Primeros **verbos**: forma ます (presente/futuro, afirmativo y negativo).
- Reconocer los 3 tipos de verbo (de momento solo para identificarlos).
- Partículas de acción: **を・に・へ・で・と**.
- Orden de palabras SOV y adverbios de frecuencia.

### 1. La forma ます
En japonés no hay una forma de futuro separada para acciones habituales o planeadas: **~ます sirve para presente y futuro a la vez**. El contexto (今日, 明日...) marca el tiempo.

| Forma | Significado |
|---|---|
| ~ます | hago / haré |
| ~ません | no hago / no haré |

食べます (たべます) — como / comeré
食べません — no como / no comeré

### 2. Los 3 tipos de verbo
Por ahora memoriza cada ます como una pieza fija (como です). Los tipos importarán de verdad cuando lleguemos a la forma て (Lección 6), pero mejor ir familiarizándote ya:

| Tipo | Diccionario | ます | Nota |
|---|---|---|---|
| Grupo 1 (u-verbs) | 飲む (のむ, beber) | 飲みます | la mayoría de verbos |
| Grupo 2 (ru-verbs) | 食べる (たべる, comer) | 食べます | terminan en 〜える/〜いる |
| Irregulares | する (hacer) ・ 来る (くる, venir) | します ・ 来ます | solo estos dos existen |

### 3. Partículas de acción
| Partícula | Función | Ejemplo |
|---|---|---|
| を | objeto directo (qué recibe la acción) | ごはんを食べます (como comida) |
| に | hora exacta | 7時に起きます (me levanto a las 7) |
| へ | dirección, "hacia" (verbos de movimiento) | 学校へ行きます (voy a la escuela) — con 行く también vale に, aquí son casi intercambiables |
| で | lugar donde ocurre la acción | 図書館で勉強します (estudio en la biblioteca) |
| で (bonus) | medio/instrumento ("en/con qué") | 車で行きます (voy en coche) |
| と | compañía, "con" | 友達と映画を見ます (veo una película con un amigo) |

👉 Distingue で (dónde ocurre algo) de に (destino/hora): 学校**に**行きます (voy A la escuela) vs 学校**で**勉強します (estudio EN la escuela).

📌 No confundas と (compañía, "con") con の (posesión, "de"): 彼女**と**映画館 = "al cine con mi novia"; 彼女**の**映画館 = "el cine de mi novia" (¡como si fuera suya!).

### 4. Orden de palabras: el verbo va SIEMPRE al final
Japonés es SOV, no SVO. Sujeto y objeto pueden moverse con cierta libertad, pero el verbo cierra la frase.

私は 7時に 朝ご飯を 食べます。— (Yo)(a las 7)(desayuno)(como) = Como el desayuno a las 7.

### 5. Adverbios de frecuencia
| Adverbio | Significado |
|---|---|
| いつも | siempre |
| たいてい | normalmente |
| よく | a menudo |
| ときどき | a veces |
| あまり〜ません | casi no |
| ぜんぜん〜ません | para nada |

⚠️ あまり y ぜんぜん **necesitan** un verbo en negativo detrás — no funcionan con este significado en afirmativo.

### Vocabulario de la lección
**Verbos:** 食べます(comer)・飲みます(beber)・見ます(みます,ver)・聞きます(ききます,escuchar/preguntar)・行きます(いきます,ir)・来ます(きます,venir)・帰ります(かえります,volver a casa)・起きます(おきます,levantarse)・寝ます(ねます,dormir/acostarse)・勉強します(べんきょうします,estudiar)
**Tiempo:** 今日(きょう,hoy)・明日(あした,mañana)・昨日(きのう,ayer)・毎日(まいにち,todos los días)・〜時(じ,~en punto)

📌 今日/明日/昨日/毎日/先週/今週/来週 **nunca** llevan に. Solo los días de la semana (月曜日に) y horas exactas (7時に) sí.

### Diálogo modelo
> A: 明日、何をしますか。
> B: 図書館で勉強します。アナさんは？
> A: 私は友達と映画を見ます。
> B: いいですね！何時に行きますか。
> A: 7時に行きます。

### 🏮 Nota cultural: quedar con alguien en Japón
- La puntualidad es casi sagrada: llegar tarde, aunque sean 5 minutos, se considera una falta de respeto real, no una informalidad menor.
- Los planes casi siempre se organizan por **LINE** (la app de mensajería dominante, no WhatsApp) más que por llamada.
- Rechazar una invitación directamente con "いいえ" suena brusco. Es más natural una negativa suave: ちょっと…(ligeramente, dejando la frase sin terminar) o今日はちょっと…(hoy es un poco... [complicado]). Aprenderás estas fórmulas indirectas más adelante, pero ya puedes reconocerlas si te las dicen.

---

## Lección 4 — 初めてのデート (La primera cita)

### Objetivos de la lección
- Decir qué hay y dónde: **あります/います** + が.
- Ubicar cosas con sustantivos de lugar + の (上/下/中...).
- Pasado de です y de verbos ます.
- Contadores básicos (枚・冊) y たくさん.
- と como "y" (entre sustantivos).

### 1. あります/います — "hay / hay algo"
Dos verbos de existencia según si es animado o no:

| Verbo | Se usa para |
|---|---|
| あります | cosas, objetos (no animados) |
| います | personas, animales (animados) |

机の上に本があります。 — Hay un libro sobre la mesa.
教室に学生がいます。 — Hay estudiantes en el aula.

👉 **が** marca aquí el sujeto: "lo que existe". Patrón: [lugar]に[cosa/persona]が あります/います。

📌 **が vs は — la distinción que más cuesta:** が anuncia información **nueva** ("esto es lo que hay"). は marca un tema **ya conocido** o contraste. Con あります/います casi siempre usarás が, porque por naturaleza estás anunciando que algo existe (información nueva). 学生**は**教室にいます (con は) significaría otra cosa: "en cuanto a esos estudiantes [ya sabidos], están en el aula" — el foco pasa a dónde están, no a que existan.

### 2. Sustantivos de lugar + の (dónde exactamente)
Japonés no tiene preposiciones tipo "sobre/bajo/dentro" — usa sustantivos de lugar conectados con の al objeto de referencia.

| Kanji | Lectura | Significado |
|---|---|---|
| 上 | うえ | encima de |
| 下 | した | debajo de |
| 中 | なか | dentro de |
| 前 | まえ | delante de |
| 後ろ | うしろ | detrás de |
| 隣 | となり | al lado de |
| 近く | ちかく | cerca de |

机の下に猫がいます。 — Hay un gato debajo de la mesa. *(机の下 = "el debajo de la mesa", como una ubicación en sí misma)*

📌 **Vocabulario práctico para usar estas posiciones:** 部屋(へや,habitación)・椅子(いす,silla)・ドア(puerta)・壁(かべ,pared)・床(ゆか,suelo)・窓(まど,ventana)・ベッド(cama). Ej: 椅子の後ろに窓があります。(Hay una ventana detrás de la silla.)

### 3. Pasado de です
| Presente | Pasado |
|---|---|
| です | でした |
| じゃないです/じゃありません | じゃなかったです/じゃありませんでした |

私は学生でした。 — Era estudiante. (ya no lo soy, o me refiero a un momento pasado)

### 4. Pasado de verbos ます
| Presente | Pasado |
|---|---|
| ~ます | ~ました |
| ~ません | ~ませんでした |

昨日、映画を見ました。 — Ayer vi una película.
先週、勉強しませんでした。 — La semana pasada no estudié.

### 5. Contadores: 枚 y 冊
Japonés cuenta objetos con **contadores** distintos según la forma/tipo de cosa (no existe un "uno, dos, tres" universal para todo). Dos que usarás pronto:

| Contador | Para qué | 1 / 2 / 3 |
|---|---|---|
| 枚(まい) | cosas planas y finas (papel, entradas, camisetas) | 一枚(いちまい)・二枚(にまい)・三枚(さんまい) |
| 冊(さつ) | libros, cuadernos (cosas encuadernadas) | 一冊(いっさつ)・二冊(にさつ)・三冊(さんさつ) |

*(Números base para referencia: 一いち・二に・三さん・四し/よん・五ご・六ろく・七しち/なな・八はち・九きゅう/く・十じゅう)*

📌 **Duración de tiempo (distinto de la hora puntual):** 〜時間(じかん) = "durante X horas", 〜日間(かかん) = "durante X días". 2時間勉強しました (estudié durante 2 horas) — no confundir con 2時に (a las 2 en punto).

### 6. たくさん — "mucho/muchos"
教室に学生がたくさんいます。 — Hay muchos estudiantes en el aula.

📌 たくさん solo = adverbio, sin partícula, se mueve con libertad cerca del verbo (毎日たくさん買いました también vale). Si quieres pegarlo directamente a un sustantivo como adjetivo, necesitas **たくさんの**: たくさんの学生が教室にいます。Mismo significado, cambia el foco.

### 7. と como "y" (entre sustantivos)
Ya conoces と como "con" (友達と). También significa "y", pero **solo entre sustantivos**, nunca entre frases/verbos (eso se verá más adelante con la forma て).

かばんと傘を買いました。 — Compré un bolso y un paraguas.

📌 と **no une verbos/frases** (eso llega con la forma て en la Lección 6). Para "fui y comí", de momento usa dos frases separadas: 映画を見ました。たくさん食べました。

### Vocabulario de la lección
デパート(grandes almacenes)・買います(かいます,comprar→買いました)・猫(ねこ,gato)・犬(いぬ,perro)・公園(こうえん,parque)・机(つくえ,mesa/escritorio)・映画館(えいがかん,cine, el edificio — distinto de 映画 = la película en sí)

### Diálogo modelo
> A: 昨日、デパートで何を買いましたか。
> B: かばんと傘を買いました。かばんは机の上にあります。見ますか。
> A: いいですね！たくさん買いましたね。

### 🏮 Nota cultural: デパート y el consumo en Japón
Los grandes almacenes (デパート) japoneses suelen tener una planta entera dedicada a comida (デパ地下, "el sótano del depa"), muy popular para comprar regalos de comida bien presentados — regalar algo envuelto con cuidado importa tanto como el propio regalo.

---

## Lección 5 — 沖縄旅行 (Viaje a Okinawa)

### Objetivos de la lección
- Los dos tipos de adjetivo (い y な) y sus 4 formas (presente/pasado × afirmativo/negativo).
- 好き/嫌い con **が** (no を) — el "gustar" japonés.
- ~ましょう/~ましょうか — proponer/invitar.
- Contador genérico つ.

### 1. Adjetivos en -い
Se conjugan solos (como si fueran mini-verbos), です solo añade cortesía, no cambia el significado.

| | Afirmativo | Negativo |
|---|---|---|
| Presente | 高い(です) | 高く**ない**(です) |
| Pasado | 高**かった**(です) | 高く**なかった**(です) |

⚠️ Excepción única: **いい** (bueno) se conjuga como si fuera よい: よくない, よかった, よくなかった (nunca いくない).

### 2. Adjetivos en -な
Funcionan casi como sustantivos: な aparece solo delante de un sustantivo, y se conjugan con です/でした igual que です normal.

| | Afirmativo | Negativo |
|---|---|---|
| Presente | きれいです | きれいじゃない(です) |
| Pasado | きれいでした | きれいじゃなかった(です) |

きれいな部屋 (habitación bonita) — el な solo aparece pegado al sustantivo, nunca al final de frase.

📌 **La clave para no liarte:** un -な se conjuga EXACTAMENTE igual que un sustantivo con です (学生です/じゃないです/でした/じゃなかったです). No es un sistema nuevo. El único sistema realmente distinto es el de -い, que conjuga solo. Regla de identificación: ¿termina en い? probablemente -い. ¿No termina en い? siempre -な. Excepciones que sí terminan en い pero son -な: きれい, 嫌い (pruébalo quitando la い y añadiendo く: 高い→高く funciona, きれい→きれく no significa nada).

📌 **Trampa clásica:** きれい y 嫌い terminan en い pero son -な, no -い. Se distingue porque un -い de verdad conjuga al quitar la い (高い→高く); きれ/きら no significan nada, así que no son adjetivos -い reales.

### 2bis. Los 3 trabajos de un adjetivo (por qué a veces "falta" una partícula)
**Regla de oro: los adjetivos nunca llevan partícula pegada a ellos mismos.** Las partículas van con los sustantivos alrededor, no con el adjetivo. Lo que cambia es el trabajo que hace:

| Trabajo | -い | -な |
|---|---|---|
| 1. Predicado (fin de frase) | これ**は**高いです。 | この部屋**は**きれいです。 |
| 2. Modifica un sustantivo (delante, pegado) | 高い本 (libro caro) | きれい**な**部屋 (cuarto bonito) |
| 3. Modifica un verbo (adverbio) | 早**く**起きます (me levanto temprano) | きれい**に**書きます (escribo con cuidado) |

El な de los -な (trabajo 2) y el く/に (trabajo 3) no son partículas — son transformaciones propias del adjetivo según su función, no algo que "se le pega o se le olvida" al azar.

### 3. 好き/嫌い — el "gustar" japonés
Son adjetivos -な (ver arriba), y lo que gusta se marca con **が**, no con を (¡ojo, no es un verbo tipo "gustar cosas" en español!). Esa partícula pertenece al sustantivo que gusta, no al adjetivo — mismo principio de la regla de oro.

私は寿司が好きです。 — Me gusta el sushi. (lit. "en cuanto a mí, el sushi es agradable")
私は納豆が嫌いです。 — No me gusta el natto.

### 4. ~ましょう/~ましょうか — "hagamos / ¿hacemos?"
Se forma sobre la raíz de ます (quita ます, añade ましょう).

行きましょう。 — ¡Vamos! (propuesta directa)
行きましょうか。 — ¿Vamos? (propuesta más suave, invitando a decidir)

### 5. Contador genérico つ
Para objetos sin contador específico (cosas variadas, no personas ni libros ni cosas planas), 1-10 tiene lecturas propias que **no** son los números normales:

一つ(ひとつ)・二つ(ふたつ)・三つ(みっつ)・四つ(よっつ)・五つ(いつつ)・六つ(むっつ)・七つ(ななつ)・八つ(やっつ)・九つ(ここのつ)・十(とお)

### Vocabulario de la lección
沖縄(おきなわ,Okinawa)・海(うみ,mar)・料理(りょうり,comida/cocina)・美味しい(おいしい,delicioso)・きれい(な)(bonito/limpio)・静か(な)(しずか,tranquilo)・寿司(すし,sushi)・納豆(なっとう,natto)・天気(てんき,tiempo/clima, ya visto)

### Diálogo modelo
> A: 沖縄の海はきれいですね。泳ぎましょうか。
> B: いいですね！あ、あのレストランの料理は美味しいですよ。
> A: 何が好きですか。
> B: 私は寿司が好きです。でも、納豆は嫌いです。

### 🏮 Nota cultural: 沖縄, un Japón distinto
Okinawa fue un reino independiente (Ryūkyū) hasta el s. XIX, con su propia lengua, comida y cultura — muchos japoneses lo ven casi como "otro país" dentro de Japón. La comida okinawense (mucho cerdo, goya amarga) es notablemente distinta al resto del país.

---

## Lección 6 — ロバートさんの一日 (Un día en la vida de Robert)

### Objetivos de la lección
- Formar la **forma て** de los verbos (clave para todo lo que viene después).
- Unir dos acciones en una frase — la solución real a tu duda antigua sobre と.
- ~てください (petición) · ~てもいいです (permiso) · ~てはいけません (prohibición).
- ~から (razón, "porque").

### 1. Cómo se forma la forma て
**Grupo 2 (ru-verbs) — el fácil:** quita る, añade て.
食べる→食べて・見る→見て・起きる→起きて

**Irregulares:** する→して・来る→来て

📌 **¿Cómo sé si un verbo en る es Grupo 1 o Grupo 2?** Mira la vocal justo antes de る: あ/う/お → Grupo 1 siempre (100% fiable). い/え → Grupo 2 normalmente, **pero con excepciones** ("falsas ichidan"): 帰る(かえる)・入る(はいる)・走る(はしる)・知る(しる)・切る(きる)・要る(いる)・減る(へる) terminan en -iru/-eru pero son Grupo 1 de verdad. No hay truco ortográfico infalible para estas — se memorizan como vocabulario, como el propio Genki las marca.

**Grupo 1 (u-verbs) — depende de la última sílaba del diccionario:**

| Termina en | Cambia a | Ejemplo |
|---|---|---|
| う・つ・る | っ+て | 買う→買って・待つ→待って・帰る→帰って |
| ぬ・む・ぶ | ん+で | 飲む→飲んで・呼ぶ→呼んで |
| く | いて | 書く→書いて |
| ぐ | いで | 急ぐ→急いで |
| す | して | 話す→話して |

⚠️ Excepción dentro del propio grupo 1: **行く→行って** (no 行いて).

### 2. Unir dos acciones: "hago A y hago B"
朝ご飯を食べて、学校へ行きます。 — Desayuno y voy a la escuela.

📌 Esto es lo que necesitabas para "vi la película y comí mucho": **映画を見て、たくさん食べました。** — nada de と entre verbos, la forma て es la pieza que faltaba. Solo el último verbo lleva el tiempo (presente/pasado); los anteriores en て quedan neutros.

### 3. ~てください — "por favor, haz..."
ちょっと待ってください。 — Espera un momento, por favor.

### 4. ~てもいいです — "se puede / está permitido"
ここで食べてもいいですか。 — ¿Se puede comer aquí?

### 5. ~てはいけません — "no se puede / está prohibido"
ここでたばこを吸ってはいけません。 — No se puede fumar aquí.

### 6. ~から — "porque"
Va detrás de la razón; razón+から puede ir antes o después de la consecuencia.
今日は忙しいですから、行きません。 — Hoy no voy porque estoy ocupado.

📌 **Alternativa: ~ので** — mismo significado ("porque"), pero más formal/objetivo (menos "yo decido/opino", más "es un hecho"). から es más frecuente en hablado casual.
今日は忙しいので、行きません。 — (mismo significado, tono algo más neutro/formal)

⚠️ Con sustantivos/-な, から se pega tras だ (学生**だ**から), pero ので sustituye だ por な (学生**な**ので, nunca 学生だので).

📌 **だから (distinto de ambas)** empieza una frase NUEVA retomando lo dicho ("por eso"): 忙しいです。**だから**、行きません。 — no se pega a la razón como から/ので, es un conector independiente. Su versión formal (pareja de ので) es **そのため**, no だから. Versión educada de だから: ですから.

### Vocabulario de la lección
待つ(まつ,esperar)・呼ぶ(よぶ,llamar)・急ぐ(いそぐ,darse prisa)・話す(はなす,hablar)・吸う(すう,fumar/aspirar)・写真を撮る(しゃしんをとる,tomar una foto)

### Diálogo modelo
> A: すみません、ここで写真を撮ってもいいですか。
> B: すみません、ここで写真を撮ってはいけません。
> A: わかりました。じゃあ、あそこへ行って、撮ります。

### 🏮 Nota cultural: pedir permiso
すみません、〜てもいいですか es una fórmula que se usa muchísimo en Japón, incluso para cosas pequeñas — preguntar antes se valora mucho más que asumir que algo está bien. てください a secas puede sonar algo directo/seco en atención al cliente; añadir お願いします o usar ~ていただけますか (más formal, más adelante) suaviza el tono.

---

## Lección 7 — 家族の写真 (Foto de familia)

### Objetivos de la lección
- **~ている**: acción en progreso y estado resultante (resuelve tu propia duda del Ej.6: "estoy cansado" = 疲れています).
- Verbo(raíz ます)+に行きます — "ir a hacer algo".
- Contar personas (人).

### 1. ~ている — dos usos distintos
Se forma sobre la forma て + いる. Tiene dos significados según el tipo de verbo:

**a) Acción en progreso** ("estoy haciendo X ahora"), con verbos de acción continuada:
今、勉強しています。 — Ahora mismo estoy estudiando.

**b) Estado resultante** ("quedé en el estado de..."), con verbos que describen un cambio puntual:
疲れています。 — Estoy cansado. (lit. "quedé en el estado de haberme cansado")
結婚しています。 — Estoy casado. (結婚する=けっこんする, casarse)

📌 Por eso 疲れた**です** no funciona bien: 疲れる describe un cambio de estado, así que su forma natural de "estar cansado ahora" es ~ている, no el pasado simple.

### 2. Verbo(ます-stem)+に行きます — "ir a hacer algo"
Quita ます de un verbo y añade に行きます: expresa el propósito del desplazamiento.

映画を見**に**行きます。 — Voy a ver una película. *(la construcción completa que reemplaza a "映画に行く", que no era natural)*
買い物に行きます。 — Voy de compras. (買い物=かいもの, ya lo conoces de la L2 como "compras")

### 3. Contar personas
| Número | Lectura | Nota |
|---|---|---|
| 1人 | ひとり | irregular |
| 2人 | ふたり | irregular |
| 3人 | さんにん | regular desde aquí |
| 4人 | よにん | |
| 何人 | なんにん | ¿cuántas personas? |

家族は4人います。 — Mi familia es de 4 personas (lit. "hay 4 personas en mi familia").

### Vocabulario de la lección
家族(かぞく,familia)・結婚する(けっこんする,casarse)・買い物(かいもの,compras, repaso)・兄(あに,hermano mayor)・姉(あね,hermana mayor)・弟(おとうと,hermano menor)・妹(いもうと,hermana menor)

📌 **Vocabulario de familia ampliado** — tabla "mi familia (llano)" vs "familia de otra persona (respeto)":

| Mi familia | Familia de otro/a | Significado |
|---|---|---|
| 父(ちち) | お父さん(おとうさん) | padre |
| 母(はは) | お母さん(おかあさん) | madre |
| 両親(りょうしん) | ご両親(りょうしん) | padres (ambos) |
| 祖父(そふ) | お祖父さん(おじいさん) | abuelo |
| 祖母(そぼ) | お祖母さん(おばあさん) | abuela |
| 息子(むすこ) | 息子さん(むすこさん) | hijo |
| 娘(むすめ) | 娘さん(むすめさん) | hija |
| 子供(こども) | お子さん(おこさん) | hijo/a, niño/a |
| 夫(おっと) | ご主人(しゅじん) | esposo |
| 妻(つま) | 奥さん(おくさん) | esposa |

Regla: tu familia = término llano. Familia ajena = お/ご+さん. 弟/妹 nunca llevan お, solo さん para los de otra persona.

### Diálogo modelo
> A: これは家族の写真ですか。何人いますか。
> B: はい、4人います。今、父は仕事をしています。母は買い物に行っています。
> A: 結婚していますか。
> B: いいえ、まだ結婚していません。

### 🏮 Nota cultural: la familia y los términos según quién habla
Los términos para familiares cambian si hablas de los tuyos o de los de otra persona — de tu propia madre dices 母(はは), pero de la madre de alguien dices お母さん(おかあさん). Es un reflejo del mismo principio de humildad/respeto que ya viste con さん: te refieres a lo tuyo de forma más plana, y a lo ajeno con más respeto.

---

## Lección 8 — バーベキュー (Barbacoa)

### Objetivos de la lección
- **Formas simples/informales** de verbos y です — la base para todo lo que viene después (citar, pensar, hablar en plan casual).
- ~と思います (creo que...) · ~と言っていました (dijo que...).
- ~ないでください (por favor, no...).
- Verbo+の+が好きです (me gusta [verbo]-ar).
- 何か/何も.

### 1. Formas simples (informal) — el cuarto tiempo que te faltaba
Hasta ahora solo usabas la forma educada (ます/です). La forma simple es la que usas con amigos/familia, y también la que necesitas DENTRO de construcciones como と思います.

| | Educada | Simple |
|---|---|---|
| Presente afirm. | 食べます | 食べる (=diccionario) |
| Presente neg. | 食べません | 食べ**ない** |
| Pasado afirm. | 食べました | 食べ**た** |
| Pasado neg. | 食べませんでした | 食べ**なかった** |

**Cómo formar ~ない (Grupo 1):** cambia la última sílaba de u→a, añade ない: 飲む→飲ま**ない**・買う→買わ**ない**(⚠️う→わ, no あ)・待つ→待た**ない**・話す→話さ**ない**。**Grupo 2:** quita る, añade ない: 食べない・見ない。**Irregulares:** しない・来ない(こない)。

**Cómo formar ~た (pasado simple):** exactamente el mismo patrón que la forma て, cambiando て→た y で→だ: 買って→買っ**た**・飲んで→飲ん**だ**・行って→行っ**た**。

**Pasado negativo:** toma la forma ~ない y cambia い→かった: 食べない→食べな**かった**。

**です/adjetivos en informal:** です→だ (学生**だ**, informal de 学生です). Los adjetivos -い ya los conoces en informal (高い/高くない/高かった/高くなかった, sin です nunca cambia nada). Los -な usan だ igual que los sustantivos: きれい**だ**。

### 2. ~と思います — "creo que..."
[frase en forma simple] + と思います.
明日は雨だと思います。 — Creo que mañana lloverá. (雨=あめ,lluvia)
高いと思います。 — Creo que es caro.

### 3. ~と言っていました — "dijo que..."
[frase en forma simple] + と言っていました.
田中さんは忙しいと言っていました。 — Tanaka dijo que estaba ocupado.

### 4. ~ないでください — "por favor, no..."
ここで写真を撮らないでください。 — Por favor, no tomes fotos aquí.

### 5. Verbo+の+が好きです — "me gusta [verbo]-ar"
の transforma el verbo en algo tratable como sustantivo, para poder usar が好きです igual que con cualquier cosa que gusta.
本を読むのが好きです。 — Me gusta leer libros. (lit. "el leer libros me gusta")

### 6. 何か / 何も
何か = "algo" (afirmativo). 何も = "nada" (⚠️ exige negativo, mismo patrón que あまり/ぜんぜん).
何か食べますか。 — ¿Comes algo? / 何も食べません。 — No como nada.

### Vocabulario de la lección
雨(あめ,lluvia)・面白い(おもしろい,interesante/divertido)・料理する(りょうりする,cocinar)・お腹が空く(おなかがすく,tener hambre)

### Diálogo modelo
> A: 明日、バーベキューをすると思いますか。
> B: たぶん大丈夫だと思います。田中さんも来ると言っていました。
> A: いいですね。あ、ここで火を使わないでください、って書いてありますよ。
> B: そうですね。あそこに行きましょう。

### 🏮 Nota cultural: educado vs. informal
Cambiar entre ます/です y las formas simples no es solo gramática — es cambiar de "registro social". Usar la forma simple con un jefe o un desconocido suena maleducado; usarla con amigos cercanos es lo normal y esperado (usar ます todo el rato con un amigo íntimo suena raro, casi distante).

---

## Lección 9 — かぶき (Kabuki)

### Objetivos de la lección
- **Calificar sustantivos con cláusulas** ("el libro que compré", "la persona que está estudiando") — en realidad, una generalización de algo que ya sabes.
- まだ~ていません — "todavía no he hecho X" (y de propina, もう~ました — "ya lo hice").
- から como "desde" (origen), distinto del から de razón que ya conoces.

### 1. Calificar sustantivos con cláusulas — el mismo patrón de siempre, ampliado
Ya sabes que un adjetivo modifica a un sustantivo pegándose delante sin nada en medio (高い本 = el libro caro, Lección 5). Pues **una frase entera puede hacer exactamente lo mismo**, con el verbo en forma simple:

| Lo que precede al sustantivo | Ejemplo | Significado |
|---|---|---|
| Verbo simple afirm. | 昨日**買った**本 | el libro que compré ayer |
| Verbo simple neg. | **読まなかった**本 | el libro que no leí |
| Verbo simple (~ている) | 日本語を**勉強している**学生 | el/la estudiante que estudia japonés |
| Adjetivo -い | **高い**本 | el libro caro *(ya lo sabías)* |
| Adjetivo -な + な | **元気な**人 | la persona que está bien/enérgica |
| Sustantivo + の | 日本語**の**先生 | el/la profesor/a de japonés *(ya lo sabías)* |

📌 Regla única para toda la tabla: **todo lo que precede a un sustantivo va en forma simple** (nunca ます/です directamente pegado a él), igual que ya hacías con los adjetivos — ahora simplemente con frases enteras. No hace falta ninguna palabra tipo "que/quien" — el orden ya lo deja claro.

### 2. まだ~ていません — "todavía no he hecho X"
まだ食べていません。 — Todavía no he comido.
宿題をまだしていません。 — Todavía no he hecho los deberes.

*(De propina, su pareja natural: もう~ました = "ya lo hice". もう食べました。— Ya he comido.)*

### 3. から como "desde" (origen) — cuidado, no confundir con el から de razón
| から | Significado | Ejemplo |
|---|---|---|
| Origen (tiempo/lugar) | "desde" | 9時**から**始まります。(Empieza desde las 9.) |
| Razón (ya visto en L6) | "porque" | 面白い**から**、読みます。(Lo leo porque es interesante.) |

Misma palabra, significado distinto — el contexto lo desambigua (con hora/lugar antes → origen; con motivo de una acción → razón).

📌 **だから ≠ から.** だから empieza una frase NUEVA retomando lo dicho ("por eso"): 忙しいです。だから、行きません。 — から se pega dentro de la misma frase a la razón. Versión educada de だから: **ですから**.

### Bonus (ya los usaste bien solo/a): てから y まで
**~てから** = "después de hacer X": 映画を見てから、晩ご飯を食べます。(Después de ver la película, ceno.)
**まで** = "hasta" (límite de tiempo/lugar): 会社まで歩いています。(Voy andando hasta la empresa.) ・ 9時まで勉強します。(Estudio hasta las 9.)

### Vocabulario de la lección
宿題(しゅくだい,deberes)・始まる(はじまる,empezar)・終わる(おわる,terminar)・もう(ya)・まだ(todavía/aún)

### Diálogo modelo
> A: 昨日買った本、もう読みましたか。
> B: いいえ、まだ読んでいません。忙しかったから。
> A: かぶきは何時から始まりますか。
> B: 6時から始まります。まだ時間がありますよ。

### 🏮 Nota cultural: かぶき (Kabuki)
El kabuki es teatro tradicional con siglos de historia, actores exclusivamente masculinos (incluso para papeles femeninos, los 女形/おやま), maquillaje y vestuario muy vistosos, y funciones que pueden durar varias horas — la gente suele entrar y salir de la sala, comer durante la función, e incluso ver solo un acto suelto con entradas específicas para eso (幕見/まくみ).

---

## Lección 10 — 冬休みの予定 (Planes de vacaciones de invierno)

### Objetivos de la lección
- Comparar dos cosas (より) y elegir entre tres o más (一番).
- Adjetivo+の como sustituto de un sustantivo repetido.
- Adjetivo+なる — "volverse/hacerse [adjetivo]".
- どちらか / どこにも.

### 1. Comparar dos cosas: より
AはBより[adjetivo]です。 — A es más [adjetivo] que B.
日本は アメリカ**より** 小さいです。 — Japón es más pequeño que EEUU.

Preguntar cuál de dos: AとBとどちらが[adjetivo]ですか。
Responder: **Aの方が**[adjetivo]です。(A es el que más... / A es más, en comparación)

### 2. Elegir entre tres o más: 一番
[grupo]の中で、Xが**一番**[adjetivo]です。 — De [grupo], X es el más [adjetivo].
果物の中で、りんごが一番好きです。 — De las frutas, la manzana es la que más me gusta. (果物=くだもの,fruta ・りんご=manzana)

### 3. Adjetivo+の — sustituto de un sustantivo ya mencionado
Igual que 私の(かばん) usa の para no repetir el sustantivo, un adjetivo+の hace lo mismo:
どちらの傘が好きですか。赤い**の**が好きです。 — ¿Cuál paraguas te gusta? Me gusta el rojo. (lit. "el rojo [uno]")

### 4. Adjetivo+なる — "volverse/hacerse [adjetivo]" (cambio de estado)
Mismo patrón adverbial que ya conoces (く para -い, に para -な), + なる:
高く**なる** — subir de precio/volverse caro. きれいに**なる** — volverse bonito/mejorar.
天気が寒くなりました。 — El tiempo se ha vuelto frío.

📌 **Bonus: と como "cuando/si..."** — [frase simple]+と+[consecuencia natural]. 冬になると、寒くなります。(Cuando llega el invierno, hace frío — una consecuencia casi automática, no una condición dudosa).

📌 **Bonus: verbo+ようになる** — mismo なる, aplicado a acciones: "llegar a hacer algo" (cambio de hábito/capacidad, no un inicio puntual). 野菜を食べるようになりました。(He llegado a comer verduras — antes no). Distinto de 食べ始めました (empecé a comer, ahora mismo).

### 5. どちらか / どこにも
どちらか = "uno de los dos, cualquiera" (afirmativo). どこにも = "en ningún sitio" (⚠️ exige negativo, mismo patrón que 何も/あまり).
どちらかに行きましょう。 — Vayamos a uno de los dos. / 今日はどこにも行きません。 — Hoy no voy a ningún sitio.

### Vocabulario de la lección
寒い(さむい,frío)・暖かい(あたたかい,cálido)・涼しい(すずしい,fresco)・冬(ふゆ,invierno)・夏(なつ,verano)・春(はる,primavera)・秋(あき,otoño)・電車(でんしゃ,tren)・果物(くだもの,fruta)

### Diálogo modelo
> A: 冬と夏と、どちらが好きですか。
> B: 季節の中で、秋が一番好きです。涼しいから。
> A: 冬は寒くなりますね。どこにも行きたくないです。
> B: そうですね。でも、電車の方がバスより便利ですよ。

### 🏮 Nota cultural: 日本の交通機関
Los trenes japoneses son extremadamente puntuales (un retraso de 1-2 minutos ya genera aviso oficial) y la red de shinkansen conecta casi todo el país. En hora punta, en las grandes ciudades, los vagones pueden ir muy llenos — hay incluso personal (押し屋/おしや) cuyo trabajo es ayudar a empujar a la gente dentro del vagón.

---

## Lección 11 — 休みのあと (Después de las vacaciones)

### Objetivos de la lección
- **~たい** — "querer hacer algo" (ya lo usaste solo/a, hoy lo formalizamos).
- **~たり~たりする** — listar acciones sin ser exhaustivo.
- **~ことがある** — "he hecho X alguna vez" (experiencia de vida).
- **noun A や noun B** — "y" para listas no cerradas.

### 1. ~たい — querer hacer algo
Raíz de ます + たい. Conjuga **como un adjetivo -い** (porque termina en い):

食べ**たい**です／食べ**たくない**です／食べ**たかった**です／食べ**たくなかった**です

📌 El objeto de lo que quieres a veces cambia de を a **が** (más natural con deseos directos): 水**が**飲みたいです。(Quiero beber agua.) — を también es válido, が suena más natural aquí.

### 2. ~たり~たりする — listar acciones (no exhaustivo)
Toma la forma た de cada verbo (cambia た→たり, だ→だり), y cierra con する en el tiempo que corresponda:

週末は、映画を見**たり**、買い物を**したり**します。 — El finde hago cosas como ver películas, ir de compras (entre otras cosas).

📌 Diferencia con la forma て uniendo acciones (L6): て da una secuencia concreta y cerrada ("hago A y luego B"). たり〜たり deja la lista abierta/no exhaustiva ("hago cosas como A y B, entre otras").

### 3. ~ことがある — tener la experiencia de haber hecho algo
Forma simple pasada (~た) + ことがあります:

日本に行った**ことがあります**。 — He estado en Japón (alguna vez, en mi vida).

📌 Distinto de solo 行きました (fui, un evento concreto): ことがある enmarca la frase como **experiencia vital**, no como suceso puntual.

### 4. Noun A や noun B — "y" para listas abiertas
と ya lo conoces como "y" (lista cerrada/completa). や es su versión abierta:

机の上に本**や**辞書があります。 — Hay libros, diccionarios (y alguna cosa más) sobre la mesa.
本**と**辞書があります。 — Hay [exactamente] un libro y un diccionario. (lista cerrada)

### Vocabulario de la lección
休み(やすみ,vacaciones/descanso)・宿題(ya visto)・旅行(りょこう,viaje)・経験(けいけん,experiencia)

### Diálogo modelo
> A: 休みの間、何をしましたか。
> B: 映画を見たり、友達と旅行に行ったりしました。あ、沖縄に行ったことがありますか。
> A: いいえ、まだ行ったことがありません。行きたいです！
> B: 机の上に沖縄の写真や本があります。見ますか。

### 🏮 Nota cultural: 夏休み・冬休み
Las vacaciones escolares japonesas no siempre coinciden con lo que esperarías: 夏休み (vacaciones de verano) suele ser más corta que en países occidentales (unas 6 semanas), mientras que hay periodos de vacaciones más cortos pero frecuentes repartidos durante el año. Muchos estudiantes usan estas vacaciones para 宿題 obligatorio y actividades de club (部活/ぶかつ), no son un parón total.

---

## Lección 12 — あげる・くれる・もらう (Dar y recibir)

### Objetivos de la lección
- あげる/くれる/もらう — el sistema de dar y recibir que cambia según la dirección.
- てあげる/てくれる/てもらう — el mismo sistema aplicado a favores.

### 1. あげる — dar (cuando el receptor NO eres tú)
[dador]は[receptor]に[cosa]をあげます。
私は田中さんにプレゼントをあげます。 — Yo le doy un regalo a Tanaka.

### 2. くれる — dar (cuando el receptor ERES tú)
Mismo significado que あげる, pero el verbo cambia si la dirección es hacia ti.
田中さんは私にプレゼントをくれます。 — Tanaka me da un regalo a mí.

⚠️ **La trampa más común:** si tú recibes, nunca uses あげる — siempre くれる. あげる es exclusivamente cuando TÚ (o tu grupo) da a otra persona.

### 3. もらう — recibir
[receptor]は[dador]に/から[cosa]をもらいます。
私は田中さんにプレゼントをもらいます。 — Yo recibo un regalo de Tanaka. (に y から son intercambiables aquí)

### Resumen visual
| Quién da | Quién recibe | Verbo |
|---|---|---|
| Yo | Otra persona | あげる |
| Otra persona | Yo | くれる |
| (perspectiva: recibo) | de otra persona | もらう |

### 4. Bonus: てあげる/てくれる/てもらう — favores
Mismo sistema, aplicado a acciones (no solo objetos):
私は友達に本を貸し**てあげます**。 — Le presto un libro a mi amigo (yo hago el favor).
友達は私に本を貸し**てくれます**。 — Mi amigo me presta un libro (él me hace el favor a mí).
私は友達に本を貸し**てもらいます**。 — Consigo que mi amigo me preste un libro (perspectiva de recibir el favor).

### Vocabulario de la lección
プレゼント(regalo)・貸す(かす,prestar)・借りる(かりる,pedir prestado)

### Diálogo modelo
> A: 誕生日に何をもらいましたか。(誕生日=たんじょうび,cumpleaños)
> B: 友達がかばんをくれました。アナさんは何かあげましたか。
> A: はい、私は花をあげました。(花=はな,flor)

### 🏮 Nota cultural: regalos y obligación social
Dar y recibir en Japón lleva un componente de **obligación recíproca** (お返し/おかえし) — recibir un regalo suele generar la expectativa de devolver algo de valor similar en otra ocasión. Esto es especialmente marcado en お中元/おちゅうげん y お歳暮/おせいぼ, los regalos de mitad y fin de año que se intercambian en el ámbito laboral/social.

---

## 🔧 Parche de gramática N5 (puntos que faltaban, sin lección dedicada)

## 🔧 Parche Marugoto A2 (puntos nuevos encontrados en el manual de Fundación Japón Madrid)

### verbo(raíz de ます)+方(かた) — "la manera de hacer X"
この漢字の**読み方**がわかりません。 — No sé cómo se lee este kanji (lit. "la manera de leer").
作り方を教えてください。 — Enséñame cómo se hace (la manera de hacerlo).

### 何でも / だれでも / どこでも — "cualquier cosa/quien/lugar"
Serie でも, distinta de か (algo/alguien/algún sitio, incierto) y も (nada/nadie/ningún sitio, con negativo).
何でも食べます。 — Como cualquier cosa. ／だれでもできます。 — Cualquiera puede hacerlo.

### が / けど — "pero" (adversativo, NO el が de sujeto)
Mismo significado, distinto registro: が formal, けど casual/hablado.
このホテルは古いです**が**、きれいです。 — Este hotel es viejo, pero está limpio. (educado)
高い**けど**、買います。 — Es caro, pero lo compro. (casual)

### ～ために — "para/por el bien de" (propósito)
健康**のために**、毎日走ります。 — Corro todos los días por mi salud.

### verbo simple+と いいですよ — sugerencia suave ("sería bueno que...")
寝る前に、お風呂に入る**といいですよ**。 — Estaría bien bañarte antes de dormir. *(más suave que ほうがいいです, sugerencia en vez de consejo directo)*

### ～に なります — tiempo transcurrido
この会社に入って10年**になります**。 — Llevo 10 años en esta empresa (lit. "se han vuelto 10 años desde que entré").

### ～てくださいませんか — petición muy educada
Más formal que てください.
この言葉の意味を教え**てくださいませんか**。 — ¿Podría explicarme el significado de esta palabra?

### んです — tono explicativo
Da contexto/explicación en vez de solo reportar un hecho: (forma simple)+んです.
明日テストがあるんです。 — Tengo examen mañana (por eso no puedo salir esta noche). Con sustantivo/-な, añade な: 静か**な**んです. んですか invita a que la otra persona se explique.

### ~すぎる — "demasiado"
Raíz de ます, o adjetivo sin い/な, + すぎる (conjuga como ru-verbo).
食べ**すぎました**。(Comí demasiado.) ・ この本は高**すぎます**。(Este libro es demasiado caro.)

### ~ほうがいいです — dar consejo ("mejor haz X")
Afirmativo va en pasado simple; negativo en presente.
もっと野菜を食べた**ほうがいいです**よ。(Mejor come más verdura.) ・ 休まない**ほうがいいです**よ。(Mejor no faltes.)

---

# 📗 GENKI II — a partir de aquí

## Lección 13 — 銀行で (En el banco)

### Objetivos de la lección
- **Forma potencial** — "poder hacer algo" (verbo propio, distinto de ~ことができる).
- **~そうです** — "parece que..." (apariencia, NO es el そうです="correcto" que ya conoces).
- **~てみる** — "probar a hacer algo".
- Frecuencia en un periodo de tiempo.

### 1. Forma potencial — "poder hacer X"
Cada verbo tiene su propia forma de "poder": no es una construcción aparte (como ~ことができる), es el verbo mismo transformado.

**Grupo 2:** quita る, añade られる. 食べる→食べ**られる**
**Grupo 1:** cambia u→e, añade る. 飲む→飲**める** ・ 話す→話**せる** ・ 書く→書**ける**
**Irregulares:** する→**できる** ・ 来る→**来られる**(こられる)

漢字が読めますか。 — ¿Puedes leer kanji?
日本語が話せます。 — Puedo hablar japonés.

📌 El objeto de un verbo potencial suele llevar **が**, no を (漢字**が**読めます, no を).

### 2. ~そうです — "parece que..." (apariencia)
⚠️ Ojo: es distinto del そうです="así es/correcto" que ya conoces (Lección 1). Este se pega a adjetivos/verbos y da una impresión visual/apariencia.

い-adjetivos: quita い, añade そうです. おいし**い**→おいし**そうです**。(Parece que está rico.)
*Excepción: いい→よさそうです*
な-adjetivos: quita な, añade そうです. 元気**そうです**。(Parece que está bien/con energía.)
Negativo: むずかしく**なさそうです**。(Parece que no es difícil.)

### 3. ~てみる — "probar a hacer algo"
Forma て + みる.
この料理を食べてみます。 — Voy a probar esta comida (a ver qué tal).

### 4. Frecuencia en un periodo
[periodo]に[número]回. 一週間**に**三回、運動します。 — Hago ejercicio 3 veces a la semana.

### Vocabulario de la lección
銀行(ぎんこう,banco)・口座(こうざ,cuenta bancaria)・現金(げんきん,efectivo)・クレジットカード(tarjeta de crédito)・暗証番号(あんしょうばんごう,PIN)・お預け入れ(おあずけいれ,depósito)・お引き出し(おひきだし,retirada)・～回(かい,~veces)・経験(ya visto)・悲しい(かなしい,triste)・うれしい(contento)・頑張る(がんばる,esforzarse)

### Diálogo modelo
> A: 漢字が読めますか。
> B: 少し読めます。でも、難しい漢字は読めません。この漢字は難しそうですね。読んでみます…あ、読めました！
> A: すごいですね。一週間に何回、漢字を勉強しますか。
> B: 三回ぐらい勉強します。

### 🏮 Nota cultural: bancos y efectivo en Japón
Aunque Japón es tecnológicamente muy avanzado, sigue siendo una sociedad muy dependiente del efectivo (現金) — muchas tiendas pequeñas y restaurantes tradicionales todavía no aceptan tarjeta. El sello personal (印鑑/はんこ) sigue usándose junto a la firma para trámites bancarios importantes.

### ~なければなりません — obligación ("tengo que hacer X")
El más importante de este grupo. Forma: quita ない de la forma negativa, añade なければなりません (o su versión hablada なきゃいけません).
毎日勉強し**なければなりません**。 — Tengo que estudiar todos los días.

### ~とき — "cuando..."
[frase simple]+とき+[frase principal]. 食べる**とき**、手を洗います。 — Cuando como, me lavo las manos.

### ~ながら — acciones simultáneas ("mientras...")
Raíz de ます + ながら. テレビを見**ながら**、ご飯を食べます。 — Como mientras veo la tele. *(la acción principal es la segunda: aquí "como" es lo principal, "ver la tele" es lo secundario)*

### ~でしょう — "probablemente"
明日は雨**でしょう**。 — Probablemente mañana llueva. (menos seguro que と思います)

### ~ませんか — invitar (alternativa a ましょうか)
一緒に行き**ませんか**。 — ¿No vamos juntos? (invitación suave)

### ~をください — pedir un objeto directo
コーヒー**をください**。 — Un café, por favor. *(distinto de てください, que pide una ACCIÓN)*

### ~がほしいです — querer un OBJETO (no una acción)
水**が欲しい**です。 — Quiero agua. *(たい es solo para verbos: 飲みたい="quiero beber"; ほしい es para cosas directamente)*

### ~つもりです — intención/plan concreto
来年、日本に行く**つもり**です。 — Tengo planeado ir a Japón el año que viene. (más concreto que 〜たい, que es solo deseo)

### どんな — "¿qué tipo de...?"
どんな音楽が好きですか。 — ¿Qué tipo de música te gusta?

### Bonus: てある vs ている, y adjetivo+くて
**てある** = estado resultante de la acción DELIBERADA de alguien: 窓が開け**てあります**。(La ventana está abierta [alguien la dejó así]). Distinto de 窓が開いて**います** (está abierta, sin especificar quién).
**Adjetivo+くて** une dos adjetivos -い ("A y B"): この部屋は広**くて**、明るいです。(Esta habitación es grande y luminosa). Los -な usan で: きれい**で**、静かです。



