# 📗 Workbook — Deberes de Japonés

Instrucciones: rellena tus respuestas debajo de cada ejercicio (en este mismo archivo, o pégalas en el chat). En la siguiente sesión las corrijo aquí mismo, en una sección "✅ Corrección", antes de añadir los deberes nuevos.

---

## Lección 1 — Deberes

### Ejercicio 1 — Lectura (conecta sonido con significado)
Lee en voz alta y luego escribe en español qué dice cada frase. No traduzcas palabra por palabra: entiende el bloque.

1. わたしはがくせいです。
   → Tu respuesta:
2. たなかさんはせんせいです。
   → Tu respuesta:
3. わたしもがくせいです。
   → Tu respuesta:
4. あなたのなまえは？
   → Tu respuesta:

### Ejercicio 2 — Completa con la partícula correcta (は / も / の / か)
1. 私＿学生です。
2. これは私＿本です。(本 = libro)
3. あなたは学生です＿。
4. 田中さん＿会社員です。(si Ana también lo es)

### Ejercicio 3 — Traduce al japonés (usa lo aprendido hoy)
1. Yo soy Ana.
2. Soy estudiante.
3. ¿Eres profesor/a?
4. No, no soy profesor/a. Soy médico.

### Ejercicio 4 — Tu autopresentación
Escribe tu propia presentación completa en japonés, con al menos 3 frases (nombre, nacionalidad, ocupación), usando は, です y よろしくお願いします.

### Ejercicio 5 (opcional, reto) — Diálogo
Inventa un mini-diálogo de 4 líneas entre tú y un/a compañero/a imaginario/a, presentándoos y preguntando si también es estudiante (usa か y も).
＋初めまして。フアンです。日本語の学生です。よろしくお願いいたします。
－初めまして。私はの名前もフアンですよ！。フアンさんは会社員ですか。　こちらこそよろしくお願いします。
＋いいえ、私は会社員出羽ありません。国家公務員です。あなたも日本語のがくせいですか。
＋はい。そおですね。わたしもがくせいです

### ✅ Corrección Lección 1
- Ej. 1 y 2: todo correcto.
- Ej. 3.4 (en blanco): いいえ、先生じゃありません。医者です。
- Ej. 4: nombres extranjeros van en katakana → 私はホアンです (no "Juan" en alfabeto latino).
- Ej. 5:
  - 私はの名前も → **私の名前も** (は y の no se combinan así; el posesivo va solo).
  - 会社員出羽ありません → **会社員じゃありません** (出羽 es un error de conversión del teclado; revisa siempre lo que el IME convierte).
  - そおですね → **そうですね** (う pequeña, no お — error de oído/escritura, tu punto a reforzar).
  - Estilo: mejor フアンさん que あなた una vez que ya sabes el nombre.
  - ですよ！。→ un solo signo de puntuación, no los dos.
- Muy bien usados por iniciativa propia: じゃありません, よ/ね, いたします, 国家公務員. Vas rápido.

---

## Lección 2 — Deberes

### Ejercicio 1 — Lectura
1. これはとけいです。
   → Tu respuesta:
2. それはだれのかばんですか。
   → Tu respuesta:
3. あのじしょはあなたのですか。
   → Tu respuesta:
4. すみません、これはいくらですか。
   → Tu respuesta:

### Ejercicio 2 — Completa (これ/それ/あれ/どれ, この/その/あの/どの, ここ/そこ/あそこ/どこ)
1. すみません、＿はなんですか。(señalando algo lejos de los dos)
2. ＿かばんはだれのですか。(la bolsa que tienes tú en la mano, cerca de ti)
3. としょかんは＿ですか。(preguntando dónde está)
4. ＿がわたしのかさです。(la tuya, lejos de ambos)

### Ejercicio 3 — Traduce al japonés
1. Esto es un diccionario.
2. Eso no es mi paraguas. (usa じゃないです o じゃありません)
3. ¿De quién es aquel reloj?
4. ¿Cuánto cuesta esto?

### Ejercicio 4 — ね vs よ
Completa con ね o よ según el matiz (ね = buscas acuerdo/confirmación; よ = das información nueva que el otro no sabe):
1. このかばんはたかいです＿。(informas del precio, el otro no lo sabía)
2. いいてんきです＿。(comentario compartido, esperas que asienta)

### Ejercicio 5 (opcional) — Diálogo de compras
Escribe un mini-diálogo de 4-6 líneas entre cliente y dependiente/a usando al menos: これ/それ/あれ, いくらですか, じゃないです/じゃありません, y una partícula ね o よ.

+こんいちは。そのとけいはかわいいですね。
-いらっしゃいませ。そうですね。このは３０００円です。
＋ああ。高いですよ。そしてこれはですか＿
－すみません、それは時計じゃありません。かばんです。
＋あああ。ありがとうございます

### ✅ Corrección Lección 1 (repaso)
Ej. 1-3: todo perfecto. Ej. 4: acaba con **。** no con ・ (el punto japonés y el punto medio son símbolos distintos). Ej. 5: 私の名前も ya corregido ✅; でわありません → **ではありません** (わ es la letra "wa" suelta, は es la partícula que también suena "wa" pero se escribe distinto — nunca se sustituyen); そおですね → **そうですね**, sigue apareciendo, mira la nota de abajo.

📌 **Patrón que se repite (importante):** そう, ありがとう, おはよう... el sonido alargado "oo" en palabras que vienen de -au/-ou se escribe casi siempre con **う**, no con お. Como en español no distinguimos ambos sonidos alargados, cuesta al oído — pero es una regla casi sin excepciones, así que memorízala como regla, no palabra por palabra.

### ✅ Corrección Lección 2
- Ej.1: todo bien. Nota de vocabulario: かばん = bolso/maletín en general, no específicamente "mochila" (eso sería リュック).
- Ej.2.3: としょかんは**どこ**ですか (no どれ). どれ = "¿cuál (de estos)?", どこ = "¿dónde?" — se confunden fácil porque suenan parecido, pero son categorías distintas (elegir vs. ubicar).
- Ej.3.1: これは**じしょです** (sin negación) — la frase pedía afirmativo "esto ES un diccionario", no negaste nada en el español pero sí en el japonés.
- Ej.3.3: あの時計は**だれの**ですか (no あのとけいのだれはですか). Mismo patrón que ya clavaste en la lectura L2 ej.1.3 (あのじしょはあなたのですか) — el objeto va primero con は, y だれの va justo antes de ですか.
- Ej.3.4: correcta, aunque añadiste とけい cuando el original solo decía "esto" genérico (これはいくらですか) — no es error, solo más específico de lo pedido.
- Ej.4: perfecto.
- Ej.5: muy bien construido el diálogo (¡buena idea lo de confundir reloj con bolso!). 3 detalles:
  - こんいちは → **こんにちは** (に, no い — mismo tipo de error de oído/escritura que そう).
  - このは３０００円です → **これは**３０００円です (この nunca va solo, justo la regla clave de esta lección — このは no existe).
  - これはですか → **これはいくらですか** (te faltó la palabra clave "いくら", si no la pregunta queda sin sentido).
  - Detalle fino: ああ、高いですよ → mejor ★ね★ aquí; よ es para cuando TÚ informas de algo que el otro no sabe, pero aquí estás reaccionando a un precio que te ACABAN de decir, así que ね (reacción/acuerdo) encaja mejor.

---

## Lección 3 — Deberes

### Ejercicio 1 — Lectura
1. まいにちがっこうへいきます。
   → Tu respuesta:
2. あさ７じにおきます。
   → Tu respuesta:
3. ときどきともだちとえいがをみます。
   → Tu respuesta:
4. わたしはあまりべんきょうしません。
   → Tu respuesta:

### Ejercicio 2 — Completa con la partícula correcta (を/に/へ/で/と)
1. 明日、図書館＿勉強します。(lugar donde ocurre)
2. ７時＿起きます。(hora exacta)
3. 毎日ごはん＿食べます。(objeto directo)
4. 友達＿映画を見ます。(compañía)
5. 明日、学校＿行きます。(dirección)

### Ejercicio 3 — Traduce al japonés
1. Como siempre desayuno a las 8. (usa いつも)
2. No estudio japonés los fines de semana. (usa あまり o ぜんぜん)
3. Voy al cine con un amigo mañana.
4. ¿A qué hora te levantas? (何時に)

### Ejercicio 4 — Tu rutina diaria
Escribe 4-5 frases sobre tu día típico usando al menos 3 verbos nuevos, un adverbio de frecuencia y una partícula de tiempo/lugar.

### Ejercicio 5 (opcional) — Quedar con un amigo
Escribe un mini-diálogo de 4-6 líneas donde propones un plan (cine, biblioteca, restaurante...) y quedáis en una hora y lugar concretos.

### ✅ Corrección Lección 3
- Ej.1: 1-3 perfectos. Ej.1.4: あまり勉強しません = **"casi no estudio"**, no "a veces no estudio" — confundiste あまり (casi no) con ときどき (a veces). Son las dos primeras palabras nuevas de frecuencia, fácil mezclarlas al principio.
- Ej.2: las 5 correctas. 🎉
- Ej.3.1: いつもに8時朝ご飯をたべます → **いつも8時に朝ご飯を食べます**. に no va pegado a いつも (いつも no lleva partícula); に va con 8時 (la hora exacta).
- Ej.3.2: あまり週末日本語を勉強します → **あまり週末（に）日本語を勉強しません**. Se te olvidó negar el verbo — あまり **exige** ~ません, si no la frase no tiene sentido (literalmente dijiste "casi estudio", que no significa nada). (に en 週末 es opcional, no te preocupes por eso).
- Ej.3.3 y 3.4: perfectas. Nota: 映画を見ます sin 行く también es súper natural para "ir al cine" — la construcción 見に行きます (ir a ver) la veremos en la Lección 7, de momento lo que hiciste está bien.
- Ej.4: 朝ご飯ご飯 → sobra un ご飯 repetido, solo error de escritura. El resto (あまり週末に仕事に行きません, 土曜日に友達と映画をみます) está perfecto, con buen uso de に en día de la semana.
- Ej.5: diálogo con buena idea de trama. 3 cosas:
  - 何**が**しますか → **何をしますか** (する siempre lleva を como objeto, no が — es justo la partícula de esta lección).
  - 図書**丘**へ行きます → **図書館**へ行きます (丘 significa "colina", el teclado te dio el kanji equivocado — segunda vez que pasa esto, revisa siempre el kanji antes de enviar, sobre todo en palabras que ya escribiste bien antes).
  - べんきょ**し**ます → **べんきょうします** (falta la う larga — mismo patrón que そう/こんにちは. Ya van 3 veces: revisa siempre las palabras con sonido largo "-ou").
  - 👏 Muy bien: 明日、ちょっと。 — usaste la negativa suave que vimos en la nota cultural. Aún mejor con は y dejándola en el aire: 明日はちょっと… (con puntos suspensivos, no punto, para mantener el tono de "no quiero decirlo directamente").

📌 **Patrón a vigilar:** las palabras con sonido largo "-ou" (べんきょう, ありがとう, おはよう, そう...) te están costando de forma sistemática — ya van 3 veces entre そう, べんきょう y variantes. Cuando dudes, pregúntate "¿esto viene de -au/-ou?" → entonces lleva う, no お. Vale la pena un repaso específico de esto en las tarjetas.

---

## Lección 4 — Deberes

### Ejercicio 1 — Lectura
1. きのうともだちのいえにいきました。
   → Tu respuesta:
2. デパートでかばんをかいました。
   → Tu respuesta:
3. きょうしつにがくせいがたくさんいます。
   → Tu respuesta:
4. つくえのうえにほんが３さつあります。
   → Tu respuesta:

### Ejercicio 2 — Completa con が o を
1. 教室に学生＿います。(が = existencia)
2. 私はご飯＿食べました。(を = objeto)
3. 机の上にねこ＿います。
4. 昨日、映画＿見ました。

### Ejercicio 3 — Pasado de です y de verbos ます
Cambia estas frases a pasado:
1. 私は学生です。→
2. 田中さんは先生じゃありません。→
3. 毎日勉強します。(ayer, no hoy) →
4. 友達と映画を見ません。(la semana pasada) →

### Ejercicio 4 — Traduce al japonés
1. Ayer compré un paraguas en unos grandes almacenes. (デパート, 買いました)
2. Hay muchos libros en la mesa. (usa ～枚 o たくさん según corresponda)
3. Fui al cine con mi amigo y comimos mucho. (usa と para unir las dos acciones simplemente con "y" — de momento solo con と entre sustantivos, no busques unir verbos aún)
4. Había un perro en el parque. (いました)

### Ejercicio 5 (opcional) — Un día que recuerdes
Escribe 4-6 frases en pasado contando qué hiciste el fin de semana pasado: adónde fuiste, qué compraste o comiste, con quién estuviste.

### ✅ Corrección Lección 4
- **Ej.1:** 1-3 y 4 casi perfectos. Ej.1.1: leíste 友達**の**家 (casa **de** mi amigo, posesión) como "con un amigo a casa" — confundiste の con と. Repásalo, es un fallo de comprensión, no de escritura.
- **Ej.2:** las 4 correctas. 🎉
- **Ej.3:** 1 y 2 perfectas. Ej.3.4: te pedía pasar 見ません (negativo) a pasado — el resultado debía seguir siendo negativo: **見ませんでした**, y escribiste 見ました (afirmativo, cambiaste el sentido). Además 先週**に** → mejor solo **先週** (los tiempos relativos como 先週/今週/来週/今日/明日 nunca llevan に, solo los días de la semana y horas exactas sí).
- **Ej.4** (la más floja, normal en la lección más densa hasta ahora):
  1. デパート**に**買いました → **デパートで**買いました. で = dónde ocurre la acción (comprar), に = destino/hora. Justo la confusión que ya vimos con 図書館で勉強します — le hice una tarjeta de gramática a esto, repásala.
  2. 机の上に本があります → correcta pero le falta "muchos": **机の上に本がたくさんあります。**
  3. 友達と私は映画に行きましたと**たべました** → dos problemas: (a) と **no une verbos**, solo sustantivos — literalmente te avisé de esto en el enunciado 🙂. Sin forma て (Lección 6) la solución es partir en dos frases: **友達と映画を見ました。たくさん食べました。** (b) 映画 = la película (el contenido); 映画館 = el cine (el edificio, adónde vas). "映画に行く" no es natural — mejor 映画館に行く o simplemente 映画を見る como en tu propio ejercicio 3 de la L3.
  4. 犬が**あいました** → **いました** (あいました no es una conjugación real; con seres vivos siempre います/いました). Y te faltó el lugar: **公園に犬がいました。**
- **Ej.5:** muy bien en general (先週、スペインに行きました。チョコレートを買いました. correctas). 彼女と映画に行きました → mismo matiz de 映画/映画館 que arriba. 映画は**高いでした**よ → buen intento, pero los adjetivos en -い (como 高い) tienen su propia conjugación de pasado, no se combinan con でした — se veremos formalmente ahora mismo en la Lección 5, así que no podías saberlo aún.

Añadí 3 tarjetas de gramática nuevas con estos matices (で/に con verbos de acción, と no une verbos, tiempos relativos sin に) — dado que fallaste 2 de los 3 hoy, van a salirte pronto en las tarjetas.

---

## Lección 5 — Deberes

### Ejercicio 1 — Lectura
1. おきなわのうみはきれいです。
   → Tu respuesta:
2. このりょうりはおいしくないです。
   → Tu respuesta:
3. きのうのてんきはあまりよくなかったです。
   → Tu respuesta:
4. わたしはねこがすきです。でも、いぬはあまりすきじゃないです。
   → Tu respuesta:

### Ejercicio 2 — Conjuga el adjetivo (presente/pasado, afirmativo/negativo)
1. 高い (caro) → pasado negativo:
2. きれい (bonito, な-adjetivo) → pasado afirmativo:
3. いい (bueno) → presente negativo:
4. 静か (tranquilo, な-adjetivo) → presente negativo:

### Ejercicio 3 — Traduce al japonés
1. Me gusta el sushi, pero no me gusta el natto. (usa 好き/嫌い con が, no を)
2. La comida japonesa es deliciosa. (美味しい)
3. ¿Vamos al parque mañana? (usa ～ましょうか)
4. Ayer no hizo buen tiempo. (usa いい en pasado negativo)

### Ejercicio 4 — たべものの　このみ (tus gustos de comida)
Escribe 3-4 frases con adjetivos (い y な) y 好き/嫌い, describiendo comidas o lugares que te gustan o no.

### Ejercicio 5 (opcional) — Un viaje
Invita a alguien a hacer un plan con ~ましょう/~ましょうか, y describe el lugar con al menos 2 adjetivos distintos (uno い y uno な).

---

## 🧪 Test de repaso — Lecciones 1-5
*(cada 5 lecciones habrá uno de estos antes de seguir — corrígelo cuando puedas, junto con la L5)*

### A — Lectura
1. 私はスペイン人の医者です。
2. きのう、デパートで新しいかばんを買いました。
3. 教室に学生がたくさんいます。でも、先生はいません。
4. この料理は美味しくないですが、あの料理は美味しいです。
5. 週末はあまり勉強しませんでした。でも、映画を見ました。

### B — Partículas (は/も/の/を/に/へ/で/と/が/か)
1. 私＿学生です。
2. 図書館＿勉強します。
3. 友達＿映画を見ました。
4. 机の上に本＿あります。
5. これは私＿かばんです。
6. 何＿好きですか。

### C — Conjugación
1. 食べます → pasado negativo:
2. 高い → pasado afirmativo:
3. きれい → presente negativo:
4. 行きます → forma ましょう:
5. 忙しい(いそがしい,ocupado) → presente negativo:

### D — Traducción
1. Ayer no fui a la escuela.
2. Hay tres gatos debajo de la mesa.
3. Me gusta el café, pero no me gusta el té.
4. ¿Quién es aquella persona? (あの人)

### E — Encuentra y corrige el error
1. 明日、図書丘へ行きます。
2. 何がしますか。
3. このは私のかばんです。
4. 映画は高いでした。
5. 友達と映画を見ましたとたべました。

### F — Producción libre
Escribe un párrafo de 5-6 frases: preséntate, di qué te gusta y qué no, y cuenta qué hiciste el fin de semana pasado.

### ✅ Progreso en el repaso de Ej.1 (L1-5)
Detecté 2 mejoras reales respecto a la primera vez: L3.ej1.4 ahora bien traducido (あまり = "casi no", ya no lo confundes con ときどき), y L4.ej1.1 ahora entiendes 友達**の**家 como "casa de un amigo" (antes lo leías como "con"). El repaso está funcionando, sigue así.

### ✅ Corrección Lección 5
- **Ej.1:** #1 y #3 perfectas. #2: おいしく**ない**です es negativo ("no está rica"), lo tradujiste en afirmativo — se te escapó el ない. #4: solo un typo en español ("gastos"→gatos), el japonés lo entendiste bien.
- **Ej.2** (la que más cuesta hoy, vamos punto por punto):
  1. 高い→pasado negativo: escribiste たくないなかった → mezclaste くない (negativo presente) con くなかった (negativo pasado). Es uno u otro: **高くなかったです**.
  2. きれい→pasado afirmativo: **きれいでした** ✅ perfecta.
  3. いい→presente negativo: pusiste よかった, que es pasado afirmativo, no presente negativo. いい se conjuga como よい: presente negativo = **よくないです**.
  4. 静か→presente negativo: 静なかった no es una forma real — los -な niegan con じゃない, no con なかった (eso es solo para い-adjetivos, y encima en pasado). Correcto: **静かじゃないです**.
  
  📌 Patrón claro: estás aplicando la conjugación de -い a todo. Regla fija: **-い adjetivos → くない/くなかった. -な adjetivos → じゃない/じゃなかった.** Nunca se cruzan. Te dejo tarjetas de conjugación específicas para automatizarlo.
- **Ej.3:** #1 perfecta. #2: 日本**語**の料理 → **日本の料理** (日本語 = el idioma japonés, no "japonés" como nacionalidad/país — para "comida japonesa" usas 日本, el país). #3: escribiste うえ (=encima, L4) en vez de こうえん (=parque, L5) — confusión de vocabulario por sonido/contexto, no de gramática: **明日、公園に行きましょうか**. #4: la pediste en negativo y la escribiste en afirmativo (よかった=hizo buen tiempo) → **昨日、天気はよくなかったです** (mismo fallo que en Ej.2.3, la conjugación de いい).
- **Ej.4:** muy bien narrado (私はミラノの山へ行きました, natural). 嫌い**デス** → mejor です en hiragana (デス en katakana es un efecto informal/tierno que no conviene en un ejercicio formal). Se quedó a medias en "でも、" — remátalo la próxima vez, aunque sea una frase corta.
- **Ej.5:** genial — きれいじゃないです correcto, y usaste 映画館 (¡bien aplicada la corrección de la L4!) además de un adjetivo -い nuevo por iniciativa propia (暑い). Cumple perfecto el reto de usar un -い y un -な.

### ✅ Corrección Test de repaso (L1-5)
- **A (lectura):** 5/5 bien entendidas. Solo un detalle: en #4 pusiste "?" pero no es pregunta, が ahí es "pero" (contraste), no か.
- **B (partículas):** 6/6 perfectas. 🎉 Sólido.
- **C (conjugación):**
  1. 食べませんでした ✅
  2. 高い→pasado afirmativo: pusiste たかった, te falta una か: es **たかかった** (高い→高+かった, no pierdas la か de la raíz).
  3. きれいじゃないです ✅
  4. 行きましょう ✅
  5. 忙しい→presente negativo: 忙しいじゃないです → mismo patrón de Ej.2 de hoy: 忙しい es -い de verdad (忙し+い), así que niega con くない, no con じゃない: **忙しくないです**.
- **D (traducción):** 4/4 perfectas, incluso usaste 三匹 (contador de animales pequeños) sin haberlo visto formalmente — muy bien.
- **E (encuentra el error)** — la sección más reveladora hoy:
  1. 図書丘 → no lo viste, pero el error está ahí: 丘(colina) debería ser 館 → **図書館**.
  2. 何がしますか → tu comentario ("falta saber quien") no es el problema real; el error es la partícula: する siempre lleva を, no が → **何をしますか**.
  3. このは→これは ✅ correcto.
  4. 映画は高いでした → aquí te desviaste: el problema NO es 映画 vs 映画館 (映画 está bien aquí, no se habla de ir a ningún sitio, solo de que algo es caro). El error real es el mismo de siempre: adjetivo -い + でした no existe → **高かったです**.
  5. と no une verbos ✅ correcto, bien explicado.
  
  📌 En esta sección el patrón es: cuando el error NO salta a la vista, tiendes a inventar uno relacionado con algo que ya conoces (映画館) en vez de seguir buscando el real. Buena señal para practicar más este tipo de ejercicio.
- **F (producción libre):** muy buen párrafo, con un extra: usaste 勉強してい**ます** (forma ~ている) que no hemos visto formalmente aún — la veremos en la Lección 7, y la usaste bien. Dos ajustes:
  - 人はたくさんです → no es la construcción natural; たくさん acompaña a あります/います, no a です suelto. Con el contexto en pasado: **人がたくさんいました**.
  - 海きれいでした → te comiste el は/が: **海は**きれいでした (o 海が, según foco).

Vas muy sólido en partículas, lectura y traducción directa. El punto a reforzar ahora mismo es 100% la conjugación de adjetivos (-い vs -な) — le puse tarjetas de conjugación dedicadas, y en cuanto lo automatices deberías dejar de fallarlo.

---

## Lección 6 — Deberes

### Ejercicio 1 — Lectura
1. すみません、ちょっと待ってください。
   → Tu respuesta:
2. ここでたばこを吸ってはいけません。
   → Tu respuesta:
3. 朝ご飯を食べて、学校へ行きます。
   → Tu respuesta:
4. 忙しいですから、今日は勉強しません。
   → Tu respuesta:

### Ejercicio 2 — Forma て (conjuga cada verbo)
1. 飲む →
2. 買う →
3. 食べる →
4. 行く →
5. 話す →
6. 待つ →
7. 起きる →
8. する →

### Ejercicio 3 — Traduce al japonés
1. Por favor, espera aquí. (usa てください)
2. ¿Se puede tomar fotos aquí? (usa てもいいですか)
3. No se puede comer en la biblioteca. (usa てはいけません)
4. No voy porque estoy cansado. (疲れる=つかれる, cansarse)

### Ejercicio 4 — Une las dos frases con て
1. 家に帰ります。／晩ご飯を食べます。(晩ご飯=ばんごはん, cena)
2. 友達と映画を見ました。／たくさん食べました。 *(¡la frase que llevabas semanas queriendo unir!)*
3. 朝起きます。／顔を洗います。(顔を洗う=かおをあらう, lavarse la cara)

### Ejercicio 5 (opcional) — Tu rutina, ahora unida
Reescribe tu rutina diaria (la de la Lección 3) pero uniendo al menos 3 acciones con la forma て, en vez de frases sueltas.

### ✅ Corrección Lección 6
- **Ej.1:** 3/4 muy bien. Solo un matiz: 忙しいですから = "porque estoy **ocupado**", no "cansado" (eso es 疲れる, que usaste bien luego en el Ej.3.4) — se te mezclaron los dos.
- **Ej.2 (forma て): 8/8 perfectas** 🎉 — incluida la excepción 行く→行って. Esta se te dio genial.
- **Ej.3:**
  1. Perfecta.
  2. 写真を撮っ**て**いいですか → te falta el **も**: **撮ってもいいですか**. Sin も no es la construcción de permiso que buscamos.
  3. 図書**悪寒**で → otra vez el IME te la juega con 図書館 (悪寒 = "escalofríos/fiebre", nada que ver) — van 3 veces ya con esta palabra en concreto, revísala siempre a mano.
  4. 疲れた**です**から → 疲れる es un verbo, no un adjetivo, así que su pasado educado es **疲れました**, no 疲れた+です: **疲れましたから、行きません**. (Más adelante, con ~ている, podrás decir también 疲れていますから — lo vemos ahora mismo en la L7).
- **Ej.4:**
  1. 家に帰って晩御飯を食べます ✅ perfecta.
  2. 友達と映画を見て、たくさん**食べます** → el verbo final es el que lleva el tiempo real de toda la cadena, y aquí tenía que ser pasado: **たくさん食べました**. La forma て en sí no lleva tiempo (eso está bien), pero el último verbo sí.
  3. Perfecta.
- **Ej.5:** buena estructura general. 去年、スペインに行きました se sale un poco del tema "rutina diaria" pero está bien construida. きれい**なかった**です → な+かった no existe; きれい es -な, así que su pasado es **きれいでした** (o negativo きれいじゃなかったです). Con 2 uniones て cumples parte del reto — para la próxima intenta una tercera.

---

## Lección 7 — Deberes

### Ejercicio 1 — Lectura
1. 今、日本語を勉強しています。
   → Tu respuesta:
2. 父は結婚していますが、弟はまだ結婚していません。
   → Tu respuesta:
3. 母は買い物に行っています。
   → Tu respuesta:
4. 家族は4人います。兄と姉がいます。
   → Tu respuesta:

### Ejercicio 2 — ~ている: ¿progreso o estado resultante?
Indica cuál de los dos matices tiene cada frase:
1. 今、映画を見ています。
2. 疲れています。
3. 結婚していますか。
4. 今、ご飯を食べています。

### Ejercicio 3 — Traduce al japonés
1. Voy a comprar un paraguas. (usa 買いに行きます)
2. Estoy cansado porque no dormí bien. (よく寝ませんでした)
3. ¿Cuántas personas hay en tu familia?
4. Mi hermano mayor está casado, pero yo no.

### Ejercicio 4 — Tu familia
Describe tu familia en 4-5 frases: cuántos sois, quién está casado, qué hace ahora mismo cada uno (con ~ている).

### Ejercicio 5 (opcional) — Un plan con に行く
Escribe 3 frases distintas usando verbo+に行きます (ver algo, comprar algo, comer algo).

### ✅ Corrección Lección 7
- **Ej.1:** #1-3 perfectas. #4: tradujiste solo la primera frase — te faltó 兄と姉がいます ("tengo un hermano mayor y una hermana mayor").
- **Ej.2: 4/4 perfectas** 🎉 — tienes clarísimo el matiz progreso vs. estado resultante, que es justo lo conceptualmente difícil de hoy.
- **Ej.3** (aquí es donde más cuesta aplicarlo en producción):
  1. 傘買い行きます → te falta **を** (傘を) y sobre todo la **に** que es el punto de la lección: **傘を買いに行きます**.
  2. 疲れ**です** → otra vez; hoy mismo vimos que es **疲れています**. Y 寝ませんから → te dieron la pista よく寝ませんでした, ábrela: **よく寝ませんでしたから、疲れています**.
  3. 何人**は**あなたの家族が → el orden va: tema primero, cantidad después, sin partícula en 何人: **あなたの家族は何人いますか**.
  4. 兄**結婚ています** → dos cosas: falta el **は** después de 兄 (van ya varias veces que se te cae el tema antes del predicado — mira si te suena de antes), y falta la **し** de 結婚: **兄は結婚しています**、私は結婚していません (aquí también falta し).
- **Ej.4:** ~ている bien aplicado en "母は結婚しています" pero en las frases de actividad (父は買い物に行きます, 弟は映画を見に行きます) usaste presente simple en vez de ~ている, y el ejercicio pedía justo "ahora mismo" → serían 買い物に行っています, 映画を見に行っています. 彼女は本を読んでいます sí está perfecta.
- **Ej.5:** diálogo simpático. "映画を見ていますよか" mezcla conceptos: ~ている pregunta por una acción EN CURSO ahora ("¿estás viendo una película?"), no sirve para invitar a algo futuro — para proponer, usa ましょうか o に行きませんか: **映画を見ませんか / 見ましょうか**. El resto genial, sobre todo 8時に寿司を食べに行きますか, ahí sí clavaste la construcción del día.

📌 Patrón que sigue apareciendo: se te cae el は/が antes del predicado (兄結婚ています, antes 名前エレナです, 海きれいでした...). Merece que lo tengas en el radar activamente al escribir, no solo al repasar.

---

## Lección 8 — Deberes

### Ejercicio 1 — Lectura
1. 明日は雨だと思います。
   → Tu respuesta:
2. 田中さんは忙しいと言っていました。
   → Tu respuesta:
3. ここで写真を撮らないでください。
   → Tu respuesta:
4. 私は本を読むのが好きです。でも、テレビを見るのは好きじゃないです。
   → Tu respuesta:

### Ejercicio 2 — Forma ない (presente negativo informal)
1. 飲む →
2. 食べる →
3. 買う →
4. する →
5. 来る →
6. 話す →

### Ejercicio 3 — Traduce al japonés
1. Creo que va a llover mañana. (usa と思います)
2. Mi amigo dijo que la película era interesante. (面白い=おもしろい, と言っていました)
3. Por favor, no hables aquí. (usa ないでください)
4. Me gusta cocinar. (料理する+のが好きです)

### Ejercicio 4 — 何か vs 何も
Completa con 何か o 何も según corresponda:
1. お腹が空きました。＿食べたいです。(quiero comer algo)
2. 今日は＿食べませんでした。(no comí nada)
3. ＿飲みますか。(¿quieres beber algo?)

### Ejercicio 5 (opcional) — Cotilleo
Escribe 3-4 frases usando と思います y と言っていました, contando qué crees tú y qué te dijo alguien sobre algún plan o persona.

### ✅ Corrección Lección 8
- **Ej.1:** #1 y #4 perfectas (¡y pillaste el matiz が→は de contraste en el #4 sin que te lo pidiera!). #2: 忙しい = "ocupado", no "cansado" — mismo lío de la L6, mézclalo menos. #3: tradujiste bien la idea pero ないでください es una petición directa ("por favor, no lo hagas"), no una prohibición-regla como てはいけません — matiz sutil, no error grave.
- **Ej.2 (forma ない): 6/6 perfectas** 🎉
- **Ej.3:**
  1. 雨と思いです → faltan dos cosas: だ antes de と (雨 es sustantivo, necesita だ en forma simple) y 思います no 思いです (no existe esa forma): **明日、雨だと思います**.
  2. 映画をと言っています、面白いです → la cita va entera y en forma simple antes de と: **友達は映画が面白いと言っていました** (con が porque 面白い es el adjetivo y 映画 su sujeto).
  3. ここ**に**話さないでください → con acciones que ocurren en un sitio, es で: **ここで話さないでください**.
  4. りょ**り**ん**する** → typo, es りょ**う**り**する** (料理する): **料理するのが好きです**.
- **Ej.4: 3/3 perfectas.**
- **Ej.5:** buen intento con dos construcciones a la vez. #1 y #4 muy bien (疲れたと言っていました, 疲れたからです). #3 se enredó: para dar tu propia opinión no hace falta el と言いました extra, basta **私は雨だと思います** — と言っていました resérvalo solo para reportar lo que OTRO dijo, no lo tuyo propio.

---

## Lección 9 — Deberes

### Ejercicio 1 — Lectura
1. 昨日買った本はとても面白いです。
   → Tu respuesta:
2. 日本語を勉強している学生はたくさんいます。
   → Tu respuesta:
3. 宿題をまだしていません。
   → Tu respuesta:
4. 映画は9時から始まります。
   → Tu respuesta:

### Ejercicio 2 — Une las dos frases con una cláusula (como en la tabla de hoy)
1. 昨日、かばんを買いました。／そのかばんは高いです。 → (une en una frase: "la bolsa que compré ayer es cara")
2. 学生が図書館で勉強しています。／その学生は忙しいです。
3. 私は本を読みませんでした。／その本はここにあります。

### Ejercicio 3 — もう vs まだ
1. 宿題を＿しましたか。はい、もうしました。(¿ya...?)
2. 映画は＿始まっていません。(todavía no ha empezado)
3. ご飯を＿食べましたか。いいえ、＿食べていません。

### Ejercicio 4 — Traduce al japonés
1. El libro que compré ayer es interesante.
2. Todavía no he hablado con ella. (話す)
3. La clase empieza desde las 10.
4. No voy porque estoy ocupado. (usa から de razón, para comparar con el から de origen de la 3)

### Ejercicio 5 (opcional) — Describe algo con una cláusula
Escribe 3 frases usando el patrón de calificar un sustantivo con una cláusula (ej. "la película que vi ayer fue...", "el amigo que vive en Tokio...").

---

## 🔄 Repaso Intensivo — Producción Libre Mezclada (L1-L9)

Antes de seguir con la L9, unos días centrados en construir frases **desde cero, sin plantillas de huecos**, mezclando toda la gramática vista hasta ahora. No busques la perfección — el objetivo es soltura, no exactitud. Mándamelas cuando las tengas, sueltas o juntas.

### 📋 Checklist de auto-revisión (repásalo tras escribir cada ronda)
- ¿Cada frase tiene su は/が antes del predicado? (tu punto débil recurrente — vigílalo activamente)
- ¿Los adjetivos -い y -な están conjugados cada uno con su propio sistema (nunca cruzados)?
- ¿Las partículas de acción son correctas (を/に/へ/で/と)?
- ¿El verbo va al final de la frase?
- Si usaste ~ている, ¿es el matiz correcto (progreso vs. estado resultante)?

### Ronda 1 — Tu semana
5-6 frases: qué haces normalmente (adverbios de frecuencia), qué hiciste ayer o el finde (pasado), y algo que todavía no has hecho (まだ~ていません).

### Ronda 2 — Tu familia, con detalle
Describe a 2-3 familiares: quiénes son, cómo son (adjetivos -い/-な), qué están haciendo ahora (~ている), y una cláusula calificando algo (ej. "mi hermano que vive en...").

### Ronda 3 — Un plan con alguien
Mini-diálogo proponiendo un plan (ましょうか/に行きませんか), usando に行く para el propósito, y から para la razón de por qué sí o no.

### Ronda 4 — Cotilleo
Algo que alguien te dijo (と言っていました) + tu propia opinión al respecto (と思います), con al menos un adjetivo.

### Ronda 5 — Un objeto y dónde está
2-3 objetos: qué son, de quién son (の), dónde están (あります/います+lugar), si te gustan o no (好き/嫌い+が).

### Ronda 6 — Reto: reescribe tu primera autopresentación
Vuelve a tu Ejercicio 4 de la Lección 1 y amplíala con todo lo que sabes ahora: familia, gustos, rutina, algo reciente que hiciste. Compara mentalmente cuánto ha crecido desde la primera vez.

---

## Lección 10 — Deberes

### Ejercicio 1 — Lectura
1. 日本はスペインより小さいです。
   → Tu respuesta:
2. 季節の中で、夏が一番好きです。
   → Tu respuesta:
3. どちらの本が面白いですか。青いのが面白いです。(青い=あおい,azul)
   → Tu respuesta:
4. 冬になると、寒くなります。
   → Tu respuesta:

### Ejercicio 2 — Completa (より / の方が / 一番 / の)
1. 電車はバス＿便利です。
2. 果物の中で、りんごが＿好きです。
3. どちらの傘が好きですか。赤い＿が好きです。
4. 電車＿バスより速いです。(速い=はやい,rápido)

### Ejercicio 3 — Traduce al japonés
1. El invierno es más frío que el verano.
2. De todas las estaciones, ¿cuál te gusta más?
3. Se ha vuelto muy caro. (usa なる)
4. Hoy no quiero ir a ningún sitio.

### Ejercicio 4 — Compara tu propia vida
Escribe 3-4 frases comparando cosas reales para ti (ciudades, estaciones, comidas...) usando より, の方が y 一番.

### Ejercicio 5 (opcional) — Diálogo de vacaciones
Mini-diálogo sobre planes de vacaciones, usando al menos una comparación y どちらか o どこにも.

### ✅ Corrección Lección 9
- **Ej.1:** 4/4 bien.
- **Ej.2:** #1 perfecta. #2 y #3: usaste から (razón) en vez de la cláusula pedida — objetivo era 図書館で勉強している学生は忙しいです / 私が読まなかった本はここにあります.
- **Ej.3:** もう va en la pregunta ("¿ya...?"), まだ solo en la respuesta negativa — usaste まだ en las preguntas de #1 y #3, tocaba もう.
- **Ej.4:** #1 perfecta. #2: 話す va con と (con quién), no を; y faltó aplicar まだ~ていません: 私はまだ彼女と話していません. #3: レッスン (no レソト) y から no se combina con に. #4 correcta.
- **Ej.5:** #2 y #3 exactas al patrón de la lección. #1 válida pero es otra construcción (の nominalizando, de la L8).

### ✅ Corrección Lección 10
- **Ej.1:** #1-2 perfectas. #4: usé と-condicional sin habértelo enseñado antes (ya está en el libro ahora) — 冬になると、寒くなります = "cuando llega el invierno, hace frío".
- **Ej.2: 4/4 perfectas.**
- **Ej.3:** #1 confundiste 涼しい(fresco) con 寒い(frío): 冬は夏より寒いです. #2 どちら es solo para 2 opciones, con 4 estaciones: 何が一番好きですか. #3 perfecta. #4 perfecta (¡y con ~たい, aún no formalizado entonces!).
- **Ej.4:** ミラ**ノ**, no ミラン. 魚の方が好きです funciona mejor con el punto de comparación explícito (肉より).
- **Ej.5:** muy bien — solo 行きま**せ**ん (te comiste la ん).

---

## Lección 11 — Deberes

### Ejercicio 1 — Lectura
1. 沖縄に行ったことがあります。
   → Tu respuesta:
2. 週末は、映画を見たり、買い物をしたりします。
   → Tu respuesta:
3. 水が飲みたいです。
   → Tu respuesta:
4. 机の上に本や辞書があります。

### Ejercicio 2 — たり~たりする (conjuga)
1. 見る／買い物をする → ______たり______たりします。
2. 食べる／寝る → ______たり______たりしました。(pasado)

### Ejercicio 3 — Traduce al japonés
1. Quiero comer sushi. (usa たい)
2. He estado en Kioto una vez. (ことがある)
3. El finde hago cosas como leer y estudiar (entre otras). (たり~たり)
4. Hay perros y gatos en el parque (y quizá algo más). (や)

### Ejercicio 4 — と vs や
Completa con と (lista cerrada) o や (lista abierta):
1. かばんの中に本＿辞書があります。(hay más cosas, no solo estas dos)
2. 私＿田中さんが行きます。(solo estos dos van, nadie más)

### Ejercicio 5 (opcional) — Tu experiencia
Escribe 3-4 frases sobre cosas que has hecho alguna vez (ことがある) y cosas que quieres hacer (たい).

### ✅ Corrección Lección 11
- **Ej.1:** Todo bien. Matiz en #1: ことがあります enfatiza "lo he hecho alguna vez", no solo "fui".
- **Ej.2: ambas correctas** 🎉
- **Ej.3:** #1 y #3 perfectas. #2: 京都**こ**いった→**に**, y ことが**います**→**あります**. #4: 公園**で**→**に** (con あります/います, el lugar va con に, no で).
- **Ej.4: 2/2 correctas.**
- **Ej.5:** muy buen uso de 回 (contador de veces) y てから. Repetiste el fallo de ことが+います→あります (van dos veces, ya lo tienes anotado como tarjeta). 日本語を勉強してのは話したい no terminó de cuajar — más simple: **日本語を話したいです**.

📌 **Regla a fijar:** ことが siempre lleva あります, nunca います — こと (la experiencia) es abstracta, no un ser vivo, da igual de qué trate la experiencia.

---

## 🧪 Test de repaso — Lecciones 6-11
*(se me pasó darlo tras la L10 — va ahora, cubriendo hasta la L11)*

### A — Lectura
1. ここで写真を撮ってもいいですか。
2. 母は買い物に行っています。
3. 田中さんは忙しいと言っていました。
4. 昨日買った本はとても面白かったです。
5. 日本はスペインより小さいです。
6. 沖縄に行ったことがあります。

### B — Partículas
1. すみません、ちょっと待っ＿ください。
2. 映画を見＿行きます。
3. 明日は雨＿と思います。
4. 宿題を＿していません。(todavía no)
5. 電車はバス＿便利です。(que)
6. 机の上に本＿辞書があります。(y algo más)

### C — Conjugación
1. 話す → forma て
2. 食べる → forma ない
3. 高い → forma pasado negativo
4. 行く → forma た
5. 静か → presente negativo simple (だ)

### D — Traducción
1. Por favor, no fumes aquí.
2. Mi padre está casado.
3. Creo que hará frío mañana.
4. He estado en Tokio una vez.

### E — Encuentra y corrige el error
1. 図書館こ行きます。
2. 母は買い物でいっています。
3. 高いでした。
4. ことがいます。

### F — Producción libre
Escribe un párrafo de 5-6 frases contando tu semana: algo que hiciste, algo que todavía no has hecho, algo que quieres hacer, y una comparación.

---

## Lección 12 — Deberes

### Ejercicio 1 — Lectura
1. 友達は私にプレゼントをくれました。
   → Tu respuesta:
2. 私は田中さんに花をあげました。
   → Tu respuesta:
3. 私は友達に本を貸してもらいました。
   → Tu respuesta:
4. 誕生日に何をもらいましたか。

### Ejercicio 2 — あげる / くれる / もらう
Elige el verbo correcto:
1. 私は母＿プレゼントをあげました／くれました。(yo doy a mi madre)
2. 友達は私＿本をくれました／あげました。(mi amigo me da a mí)
3. 私は友達＿プレゼントをもらいました。(yo recibo de mi amigo)

### Ejercicio 3 — Traduce al japonés
1. Le di un libro a mi hermano.
2. Mi amiga me dio un paraguas.
3. Recibí un regalo de mi madre.
4. Mi amigo me prestó dinero. (お金=おかね,dinero, 貸してくれました)

### Ejercicio 4 — Corrige el error de dirección
1. 私は田中さんにプレゼントをくれました。(¿está bien si YO soy quien da?)
2. 母は私にプレゼントをあげました。(¿está bien si YO soy quien recibe?)

### Ejercicio 5 (opcional) — Un cumpleaños
Escribe 4-5 frases sobre un cumpleaños (tuyo o de alguien), usando あげる, くれる y もらう al menos una vez cada uno.

---

# GENKI II

## Lección 13 — Deberes

### Ejercicio 1 — Lectura
1. 漢字が読めますか。少し読めます。
   → Tu respuesta:
2. このケーキ、美味しそうですね。食べてみます。
   → Tu respuesta:
3. 一週間に二回、日本語を勉強します。
   → Tu respuesta:
4. 難しくなさそうですが、実は難しいです。(実は=じつは,en realidad)

### Ejercicio 2 — Forma potencial (conjuga)
1. 話す →
2. 食べる →
3. 書く →
4. する →
5. 来る →
6. 飲む →

### Ejercicio 3 — そうです (apariencia): conjuga
1. おいしい →
2. 元気 →
3. いい →
4. 難しい (negativo) →

### Ejercicio 4 — Traduce al japonés
1. Puedo hablar un poco de japonés, pero no puedo escribir kanji.
2. Esa película parece interesante.
3. Voy a probar a hacer este plato. (料理を作る)
4. Voy al gimnasio 3 veces por semana.

### Ejercicio 5 (opcional) — Tus habilidades
Escribe 3-4 frases sobre qué puedes y no puedes hacer, usando la forma potencial.



